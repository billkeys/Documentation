/*-
 * Copyright (c) 2005 Panasonic Corporation of North America
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *
 * Copyright (c) 2001 Networks Associates Technology, Inc.
 * All rights reserved.
 *
 * This software was developed for the FreeBSD Project by NAI Labs, the
 * Security Research Division of Network Associates, Inc. under
 * DARPA/SPAWAR contract N66001-01-C-8035 ("CBOSS"), as part of the DARPA
 * CHATS research program.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * $Id$
 * $FreeBSD: src/sys/security/lomac/kernel_log.c,v 1.2 2002/03/13 22:55:20 rwatson Exp $
 */

#include "lomacfs.h"

#include "kernel_interface.h"

#include <linux/slab.h>
#include <linux/fs.h>

#define	VERBOSITY_SETTING(level) 					\
	unsigned int lomac_verbose_##level = 1;
//xxxx	SYSCTL_UINT(_kern_lomac_verbose, OID_AUTO, level,
//xxxx	    CTLFLAG_RW, &lomac_verbose_##level, 1, "")

#include "kernel_log.h"
#include "kernel_util.h"

/* sbuf_start()
 *
 * in:     nothing
 * out:    nothing
 * return: struct sbuf * to pass to later callers
 *
 */

lomac_log_t *
log_start(void) {
	lomac_log_t *s;
	s = kmalloc(sizeof(lomac_log_t), GFP_ATOMIC);
	s->length = 0;
	s->str[s->length] = '\0';
//xxxx  log_append_string(s, LOG_PREFIX);
	return (s);
} /* log_start() */


/* log_append_string()
 *
 * in:     s - a struct sbuf *
 * in:     data_s - null-terminated string to append to log
 * out:    nothing, see description for side-effects
 * return: nothing
 *
 *     This function appends `data_s' to `log_s', being careful to ensure
 * that there is sufficient room in `log_s' for the data and a null 
 * terminator.  If there is insufficient room in `log_s' for the entire
 * `data_s' string, this function will append only the prefix of `data_s'
 * which fits.
 *
 */

void	
log_append_string(lomac_log_t *s, const char *data_s) {
	int leftover_length;
	if (data_s) {
		leftover_length = strnlen(data_s,
					  LOG_BUFFER_LENGTH - s->length -1);
		strncat(s->str, data_s, leftover_length);
		s->length += leftover_length;
		s->str[s->length]= '\0';
	}
} /* log_append_string */


/* log_append_int()
 *
 * in:     data - integer value to append to log
 * out:    nothing, see description for side-effects
 * return: nothing
 *
 *     This function determines the ASCII representation of the integer
 * value in `data' and, if there is sufficient room, appends this
 * ASCII representation to `log_s'.  If there is insufficient room,
 * this function behaves as log_append_string().
 *
 */

void
log_append_int(lomac_log_t *s, int data) {
	char ascii_str[MAX_DIGITS];
	sprintf((ascii_str), "%u", (data));
	log_append_string(s, ascii_str);
} /* log_append_int() */


/* log_append_subject_id()
 *
 * in:     p_subject - subject whose ID we want to append to the log message
 * out:    nothing, see description for side-effects
 * return: nothing
 *
 *    This function appends a string describing the identity of `p_subject'
 * to `log_s'.  If there is insufficient room in `log_s' for the entire
 * ID string, only a (possibly empty) prefix of the ID string will be
 * appended.
 *
 */

void
log_append_subject_id(lomac_log_t *s, const lomac_subject_t *p_subject) {
	uid_t uid;
	pid_t pgid;

	uid = p_subject->uid;
	pgid = p_subject->signal->pgrp;

	log_append_string(s, "p");
	log_append_int(s, p_subject->pid);
	log_append_string(s, "g");
	log_append_int(s, pgid);
	log_append_string(s, "u");
	log_append_int(s, uid);
} /* log_append_subject_id() */

/* log_append_subject_name()
 *
 * in:     p_subject - subject whose ID we want to append to the log message
 * out:    nothing, see description for side-effects
 * return: nothing
 *
 *    This function appends a string containing the name of `p_subject'
 * to `log_s'.  If there is insufficient room in `log_s' for the entire
 * name string, only a (possibly empty) prefix of the ID string will be
 * appended.
 *
 */

void
log_append_subject_name(lomac_log_t *s, const lomac_subject_t *p_subject) {
	char buf[LOMAC_MAX_PATH_LEN];
	char *name;

	name = get_task_pathname((struct task_struct *) p_subject,
				 buf, LOMAC_MAX_PATH_LEN);

	log_append_string(s, name);
} /* log_append_subject_name() */


/* log_append_object_id()
 *
 * in:     p_object - object whose ID we want to append to the log message
 * out:    nothing, see description for side-effects
 * return: nothing
 *
 *    This function appends a string describing the identity of `p_object'
 * to `log_s'.  If there is insufficient room in `log_s' for the entire
 * ID string, only a (possibly empty) prefix of the ID string will be
 * appended.
 *
 */

void
log_append_object_id(lomac_log_t *s, const lomac_object_t *p_object) {
	struct lomac_node *ln;
	char buf[LOMAC_MAX_PATH_LEN];
	char *name;

	switch (p_object->lo_type) {
	case LO_TYPE_INODE:
		name = get_inode_pathname(p_object->lo_object.inode,
					  buf, LOMAC_MAX_PATH_LEN);
		log_append_string(s, name);
		
		ln = p_object->lo_object.inode->i_security;
		if (ln->ln_entry == NULL &&
		    ln->ln_underpolicy != NULL) {
			log_append_string(s, " under ");
			log_append_string(s, ln->ln_underpolicy->ln_path);
		}
		break;
	default:
		panic("invalid LOMAC object type");
	}
} /* log_append_object_id() */

/* log_append_parent_object_id()
 *
 * in:     p_object - object whose ID we want to append to the log message
 * out:    nothing, see description for side-effects
 * return: nothing
 *
 *    This function appends a string describing the identity of `p_object'
 * to `log_s'.  If there is insufficient room in `log_s' for the entire
 * ID string, only a (possibly empty) prefix of the ID string will be
 * appended.
 *
 */

void
log_append_parent_object_id(lomac_log_t *s, const lomac_object_t *p_object)
{
	struct lomac_node *ln;

	switch (p_object->lo_type) {
	case LO_TYPE_INODE:
		ln = p_object->lo_object.inode->i_security;
		if (ln->ln_underpolicy != NULL) {
			log_append_string(s, " under ");
			log_append_string(s, ln->ln_underpolicy->ln_path);
		}
		break;
	default:
		panic("invalid LOMAC object type");
	}
} /* log_append_parent_object_id() */

/* log_print()
 *
 * in:     nothing
 * out:    nothing
 * return: nothing
 *
 *     This function prints `log_s' to the system log.
 *
 */

void
log_print(lomac_log_t *s) {

  printk(s->str);

} /* log_print() */
