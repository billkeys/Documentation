/*-
 * Copyright (c) 2005 Panasonic Corporation of North America
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *
 * Copyright (c) 2001 Networks Associates Technology, Inc.
 * All rights reserved.
 *
 * This software was developed for the FreeBSD Project by NAI Labs, the
 * Security Research Division of Network Associates, Inc. under
 * DARPA/SPAWAR contract N66001-01-C-8035 ("CBOSS"), as part of the DARPA
 * CHATS research program.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * $Id$
 * $FreeBSD: src/sys/security/lomac/policy_plm.h,v 1.2 2002/03/13 22:55:20 rwatson Exp $
 */

#ifndef	LOMAC_PLM_H
#define	LOMAC_PLM_H

enum plm_level {
	LOW,
	SUBJ,
	HIGH
};
enum plm_flags {
	PLM_NOFLAGS, /* rule applies to this node and its children */
	PLM_CHILDOF  /* rule applies to node's children, not the node */
};
#define	LOWWRITE	LN_ATTR_LOWWRITE
#define	LOWNOOPEN	LN_ATTR_LOWNOOPEN
#define	NONETDEMOTE	LN_ATTR_NONETDEMOTE
#define	NODEMOTE	LN_ATTR_NODEMOTE
#define LOWMAYOPEN	LN_ATTR_LOWMAYOPEN


static u_int plm_levelflags_to_node_flags[3][2] = {
	{ LN_LOWEST_LEVEL,	LN_INHERIT_LOW },
	{ LN_SUBJ_LEVEL,	LN_INHERIT_SUBJ },
	{ LN_HIGHEST_LEVEL,	LN_INHERIT_HIGH }
};


typedef struct plm_rule {
	enum plm_level level;		/* LOMAC level */
	enum plm_flags flags;		/* flags for PLM evaluation */
	unsigned int attr;		    /* LN_ATTR_MASK of flags */
	const char *path;		    /* absolute path for this PLM rule */
} plm_rule_t;


static plm_rule_t plm[] = {
  { HIGH, PLM_NOFLAGS, 0,           "/" },  /* all initially inherit high */
  { HIGH, PLM_CHILDOF, 0,	    "/" },

  { HIGH, PLM_NOFLAGS, 0,           "/bin" },
  { HIGH, PLM_CHILDOF, LOWMAYOPEN,  "/bin" },
  { HIGH, PLM_NOFLAGS, 0,           "/etc" },
  { HIGH, PLM_CHILDOF, LOWMAYOPEN,  "/etc" },
  { LOW,  PLM_CHILDOF, 0,           "/home" }, 
  { LOW,  PLM_NOFLAGS, 0,           "/host" },	// Mount point for host machine
  { LOW,  PLM_CHILDOF, 0,           "/host" },
  { HIGH, PLM_NOFLAGS, 0,           "/lib" },
  { HIGH, PLM_CHILDOF, LOWMAYOPEN,  "/lib" },
  { LOW,  PLM_CHILDOF, 0,           "/mnt" },
  { HIGH, PLM_NOFLAGS, LOWMAYOPEN,  "/proc" },
  { HIGH, PLM_CHILDOF, LOWMAYOPEN,  "/proc" },
  { HIGH, PLM_NOFLAGS, 0,           "/sbin" },
  { HIGH, PLM_CHILDOF, LOWMAYOPEN,  "/sbin" },
  { HIGH, PLM_NOFLAGS, 0,	    "/tmp" },
  { SUBJ, PLM_CHILDOF, LOWMAYOPEN | LOWWRITE, "/tmp" },
  { HIGH, PLM_CHILDOF, 0,           "/var" },

  { HIGH, PLM_NOFLAGS, 0,           "/dev/log" },
  { LOW,  PLM_NOFLAGS, 0,           "/dev/printer" },
  { SUBJ, PLM_NOFLAGS, 0,	    "/dev/null" },
  { SUBJ, PLM_NOFLAGS, 0,	    "/dev/random" },
  { SUBJ, PLM_NOFLAGS, 0,	    "/dev/urandom" },
  { SUBJ, PLM_NOFLAGS, 0,	    "/dev/tty" },
  { SUBJ, PLM_NOFLAGS, 0,	    "/dev/tty1" },

  { HIGH, PLM_NOFLAGS, 0,           "/home/ftp" },
  { HIGH, PLM_NOFLAGS, 0,           "/home/samba" },
  { HIGH, PLM_NOFLAGS, 0,           "/home/httpd" },

  { HIGH, PLM_NOFLAGS, 0,           "/mnt/cdrom" }, /* cdrom is high */

  { HIGH, PLM_NOFLAGS, 0,           "/opt/lomac/bin" },
  { HIGH, PLM_CHILDOF, LOWMAYOPEN,  "/opt/lomac/bin" },

  { HIGH, PLM_NOFLAGS, NODEMOTE,    "/sbin/syslogd" },
  { HIGH, PLM_NOFLAGS, NODEMOTE,    "/sbin/minilogd" },

  { HIGH, PLM_NOFLAGS, 0,           "/usr/bin" },
  { HIGH, PLM_CHILDOF, LOWMAYOPEN,  "/usr/bin" },
  { HIGH, PLM_NOFLAGS, 0,           "/usr/lib" },
  { HIGH, PLM_CHILDOF, LOWMAYOPEN,  "/usr/lib" },
  { HIGH, PLM_NOFLAGS, LOWWRITE,    "/usr/tmp" },
  { SUBJ, PLM_CHILDOF, 0,           "/usr/tmp" },
  { LOW,  PLM_NOFLAGS, 0,           "/usr/src" },
  { LOW,  PLM_CHILDOF, 0,           "/usr/local" },
  { HIGH, PLM_NOFLAGS, 0,	    "/usr/X11R6" },
  { HIGH, PLM_CHILDOF, LOWMAYOPEN,  "/usr/X11R6" },

  { HIGH, PLM_NOFLAGS, LOWWRITE,    "/var/tmp" },
  { SUBJ, PLM_CHILDOF, 0,           "/var/tmp" },
  { HIGH, PLM_NOFLAGS, 0,           "/var/run" },
  { HIGH, PLM_CHILDOF, LOWMAYOPEN,  "/var/run" },
  { HIGH, PLM_CHILDOF, LOWWRITE,    "/var/log" },
  { HIGH, PLM_CHILDOF, 0,           "/var/lib" },
  { HIGH, PLM_NOFLAGS, 0,           "/var/spool" },

//xxxxxxx  { HIGH, PLM_NOFLAGS, LOWMAYOPEN,  "/etc/sysconfig/i18n" },
  
  { HIGH, PLM_NOFLAGS, 0,	    "/usr/kerberos/man" },
  { HIGH, PLM_CHILDOF, LOWMAYOPEN,  "/usr/kerberos/man" },

  { HIGH, PLM_NOFLAGS, 0,	    "/usr/lib/locale" },
  { HIGH, PLM_CHILDOF, LOWMAYOPEN,  "/usr/lib/locale" },
  
  { HIGH, PLM_NOFLAGS, 0,	    "/usr/share" },
  { HIGH, PLM_CHILDOF, LOWMAYOPEN,  "/usr/share" },

  { HIGH, PLM_NOFLAGS, 0,           "/var/cache/man" },
  { SUBJ, PLM_CHILDOF, 0,	    "/var/cache/man" },
  { HIGH, PLM_CHILDOF, 0,           "/var/lib/rpm" },
  { HIGH, PLM_CHILDOF, 0,           "/var/lib/nfs" },
  { HIGH, PLM_NOFLAGS, 0,           "/var/log/secure" },
  { HIGH, PLM_NOFLAGS, 0,           "/var/log/lastlog" },
  { HIGH, PLM_NOFLAGS, 0,           "/var/log/messages" },
  { LOW,  PLM_NOFLAGS, 0,           "/var/spool/mqueue" },
  { LOW,  PLM_CHILDOF, 0,	    "/var/spool/mqueue" },
  { LOW,  PLM_NOFLAGS, 0,           "/var/spool/mail" },
  { LOW,  PLM_CHILDOF, 0,	    "/var/spool/mail" },

  { 0, 0, 0 }
};



#endif /* LOMAC_PLM_H */
