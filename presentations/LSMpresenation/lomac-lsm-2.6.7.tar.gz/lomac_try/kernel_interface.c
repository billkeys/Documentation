/*-
 * Copyright (c) 2005 Panasonic Corporation of North America
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *
 *
 * Copyright (c) 2001 Networks Associates Technology, Inc.
 * All rights reserved.
 *
 * This software was developed for the FreeBSD Project by NAI Labs, the
 * Security Research Division of Network Associates, Inc. under
 * DARPA/SPAWAR contract N66001-01-C-8035 ("CBOSS"), as part of the DARPA
 * CHATS research program.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * $Id$
 * $FreeBSD: src/sys/security/lomac/kernel_interface.c,v 1.2 2002/03/13 22:55:20 rwatson Exp $
 */

#include <linux/slab.h>
#include <linux/fs.h>
#include <net/sock.h>

#include "lomac.h"
#include "kernel_interface.h"
#include "lomacfs.h"

/*
 * Reuse the eflags field of proc.p_vmspace->vm_map.header (since it is
 * currently not used for anything but a placeholder, and won't change
 * generally...) as storage for our process-based information.
 *
 * This is the only really effective way to make thread-based MAC
 * easy.
 */

/* xxxxxxx
 * Change this later to use p->security in a sane manner
 */

//xxxxxxx#define	p_eflags p_vmspace->vm_map.header.eflags
#define	EF_HIGHEST_LEVEL	0x00010000
#define	EF_LOWEST_LEVEL		0x00020000
#define	EF_LEVEL_MASK		0x00030000
#define	EF_ATTR_NONETDEMOTE	0x00040000
#define	EF_ATTR_NODEMOTE	0x00080000
#define	EF_ATTR_MASK		0x000c0000


void
init_subject_lattr(lomac_subject_t *p, lattr_t *lattr) {
    lattr_t *task_sec;

    if (p->security == NULL) {
        p->security = kmalloc(sizeof(lattr_t), GFP_KERNEL);
        if (p->security == NULL) {
            return;
        }
    }
    
    task_sec = (lattr_t *)p->security;
    task_sec->level = lattr->level;
    task_sec->flags = lattr->flags;
}

/*
 * Set/get the subject level on a process.  The process must not be able
 * to change, so either the process must be locked on entry or it must
 * be held in exclusivity otherwise (executing on behalf of via a syscall,
 * including as EITHER child or parent in a fork).
 */
void
set_subject_lattr(lomac_subject_t *p, lattr_t lattr) {
    lattr_t *task_sec;

#ifdef INVARIANTS
	do {
		lattr_t oslattr;

		get_subject_lattr(p, &oslattr);
		if (lomac_must_demote(&lattr, &oslattr))
			panic("raising subject level");
	} while (0);
#endif /* !INVARIANTS */
    task_sec = (lattr_t *)p->security;
    if (!task_sec) {
        return;
    }

    KERNEL_ASSERT("invalid level", IS_VALID_LEVEL(lattr.level));
    KERNEL_ASSERT("invalid flags", IS_VALID_FLAGS(lattr.flags));

    task_sec->level = lattr.level;
    task_sec->flags = lattr.flags;
}

void
get_subject_lattr(lomac_subject_t *p, lattr_t *lattr) {
	lattr_t *task_sec;

	task_sec = (lattr_t *)p->security;
	*lattr = *task_sec;
	
//	PDEBUG("in get_subject_lattr, level %d\n", lattr->level);

	KERNEL_ASSERT("invalid level", IS_VALID_LEVEL(lattr->level));
	KERNEL_ASSERT("invalid flags", IS_VALID_FLAGS(lattr->flags));
	KERNEL_ASSERT("subj level", lattr->level != LOMAC_SUBJ_LEVEL);
}

static __inline u_int
level2lvnodebits(level_t level) {

	switch (level) {
	case LOMAC_HIGHEST_LEVEL:
		return (LN_HIGHEST_LEVEL);
	case LOMAC_LOWEST_LEVEL:
		return (LN_LOWEST_LEVEL);
	case LOMAC_SUBJ_LEVEL:
		return (LN_SUBJ_LEVEL);
	default:
//		panic("level2lvnodebits: invalid level %d\n", level);
		KERNEL_ASSERT("invalid level", 1 == 0);
		return 0;
	}
}

static __inline level_t
lvnodebits2level(u_int flags) {
	KERNEL_ASSERT("No level for inode", flags & LN_LEVEL_MASK);

	switch (flags & LN_LEVEL_MASK) {
	case LN_HIGHEST_LEVEL:
		return LOMAC_HIGHEST_LEVEL;
	case LN_LOWEST_LEVEL:
		return LOMAC_LOWEST_LEVEL;
	case LN_SUBJ_LEVEL:
		return LOMAC_SUBJ_LEVEL;
	default:
//		panic("lvnodebits2level: invalid flags %#x\n", flags);
		KERNEL_ASSERT("lvnodebits2level: invalid flags", 1 == 0);
		return 297381;
	}
}

static __inline unsigned int
attr2lvnodebits(unsigned int attr) {
	unsigned int bits = 0;

	if (attr & LOMAC_ATTR_LOWWRITE)
		bits |= LN_ATTR_LOWWRITE;
	if (attr & LOMAC_ATTR_LOWNOOPEN)
		bits |= LN_ATTR_LOWNOOPEN;
	if (attr & LOMAC_ATTR_LOWMAYOPEN)
		bits |= LN_ATTR_LOWMAYOPEN;
	if (attr & LOMAC_ATTR_NONETDEMOTE)
		bits |= LN_ATTR_NONETDEMOTE;
	if (attr & LOMAC_ATTR_NODEMOTE)
		bits |= LN_ATTR_NODEMOTE;
	return (bits);
}

static __inline unsigned int
lvnodebits2attr(unsigned int bits) {
	unsigned int attr = 0;

	if (bits & LN_ATTR_LOWWRITE)
		attr |= LOMAC_ATTR_LOWWRITE;
	if (bits & LN_ATTR_LOWNOOPEN)
		attr |= LOMAC_ATTR_LOWNOOPEN;
	if (bits & LN_ATTR_LOWMAYOPEN)
		attr |= LOMAC_ATTR_LOWMAYOPEN;
	if (bits & LN_ATTR_NONETDEMOTE)
		attr |= LOMAC_ATTR_NONETDEMOTE;
	if (bits & LN_ATTR_NODEMOTE)
		attr |= LOMAC_ATTR_NODEMOTE;
	return (attr);
}

#define	OBJ_LOWEST_LEVEL	0x8000	/* the highest level is implicit */

/*
 * This code marks pipes with levels.  We use a previously unnused bit
 * in the pipe_state field of struct pipe to store the level
 * information.  Bit clear means LOMAC_HIGHEST_LEVEL, bit set means
 * LOMAC_LOWEST_LEVEL.  Since new pipes have clear bits by default,
 * using clear bit as highest causes new pipes to start at the highest
 * level automatically.
 */
#define PIPE_LEVEL_LOWEST 0x10000000

/* This code marks sockets created by socketpair() with levels.  It
 * uses a previouslt unused bit in the so_state field of struct socket
 * to store the level information.  Bit clear means
 * LOMAC_HIGHEST_LEVEL, bit set means LOMAC_LOWEST_LEVEL.  Since new
 * sockets have clear bits by default, using clear bit as highest
 * causes new sockets to start at the highest level automatically.
 */
#define SOCKET_LEVEL_LOWEST 0x4000

void
set_object_lattr(lomac_object_t *obj, lattr_t lattr) {
	struct lomac_node *ln;
	struct socket *socket;
	struct inode *ino;

	switch (obj->lo_type) {
	case LO_TYPE_INODE:
		ln = obj->lo_object.inode->i_security;
		ln->ln_flags =
		    (ln->ln_flags & ~(LN_LEVEL_MASK | LN_ATTR_MASK)) |
		    level2lvnodebits(lattr.level) |
		    attr2lvnodebits(lattr.flags);
		if(!IS_LN_VALID_LEVEL((ln->ln_flags)))
		  printk("set_object_lattr: invalid level\n");
		if(!IS_LN_VALID_FLAGS((ln->ln_flags)))
		  printk("set_object_lattr: invalid flags\n");
		break;
	case LO_TYPE_SOCKETPAIR:
		socket = obj->lo_object.socket;
		ino = SOCK_INODE(socket);
		ln = (struct lomac_node *) ino->i_security;
		
		ln->ln_flags =
		    (ln->ln_flags & ~(LN_LEVEL_MASK | LN_ATTR_MASK)) |
		    level2lvnodebits(lattr.level) |
		    attr2lvnodebits(lattr.flags);
		KERNEL_ASSERT("invalid level",
			      IS_LN_VALID_LEVEL((ln->ln_flags)));
		KERNEL_ASSERT("invalid flags",
			      IS_LN_VALID_FLAGS((ln->ln_flags)));
		break;
	default:
		panic("set_object_lattr: invalid lo_type %d", obj->lo_type);
	}
}

void
get_object_lattr(const lomac_object_t *obj, lattr_t *lattr)
{
	struct lomac_node *ln;
	struct socket *socket;
	struct inode *ino;

	switch (obj->lo_type) {
	case LO_TYPE_INODE:
		ln = obj->lo_object.inode->i_security;
		KERNEL_ASSERT("No security for inode", ln != NULL);
		lattr->level = lvnodebits2level(ln->ln_flags);
		lattr->flags = lvnodebits2attr(ln->ln_flags);
		break;
	case LO_TYPE_SOCKETPAIR:
		socket = obj->lo_object.socket;
		ino = SOCK_INODE(socket);
		ln = ino->i_security;
		lattr->level = lvnodebits2level(ln->ln_flags);
		lattr->flags = lvnodebits2attr(ln->ln_flags);
		break;
	default:
		printk("get_object_lattr: invalid lo_type %d", obj->lo_type);
		KERNEL_ASSERT("Invalid type", 1 == 0);
	}

	KERNEL_ASSERT("invalid level", IS_VALID_LEVEL(lattr->level)
		|| lattr->level == LOMAC_SUBJ_LEVEL);
	KERNEL_ASSERT("invalid flags", IS_VALID_FLAGS(lattr->flags));
}


/*
 * Flag certain procs, like init(8) and kthreads, as "invincible".
 */
int
subject_do_not_demote(lomac_subject_t *subj) {
	int inv = 0;
	if (subj->pid == 1) {
		// Don't demote "init"
		inv = 1;
	}
	return (inv);
}



