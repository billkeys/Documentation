/*-
 * Copyright (c) 2005 Panasonic Corporation of North America
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *
 * Copyright (c) 2001 Networks Associates Technology, Inc.
 * Copyright (c) 1982, 1986, 1989, 1991, 1993
 *	The Regents of the University of California.  All rights reserved.
 * (c) UNIX System Laboratories, Inc.

 * This software was developed for the FreeBSD Project by NAI Labs, the
 * Security Research Division of Network Associates, Inc. under
 * DARPA/SPAWAR contract N66001-01-C-8035 ("CBOSS"), as part of the DARPA
 * CHATS research program.
 *
 * All or some portions of this file are derived from material licensed
 * to the University of California by American Telephone and Telegraph
 * Co. or Unix System Laboratories, Inc. and are reproduced herein with
 * the permission of UNIX System Laboratories, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * $Id$
 * $FreeBSD: src/sys/security/lomac/kernel_util.c,v 1.4 2002/03/13 22:55:20 rwatson Exp $
 */

#include <linux/list.h>
#include <linux/mm.h>
#include <linux/sched.h>
#include <linux/slab.h>
#include <linux/dcache.h>
#include <linux/socket.h>
#include <linux/un.h>
#include <linux/mount.h>
#include <net/sock.h>
#include <net/af_unix.h>

#include "lomac.h"
#include "kernel_interface.h"
#include "lomacfs.h"
#include "kernel_plm.h"

/* ==================================================================== */

int inode_alloc_security (struct inode *inode);
int sb_alloc_security (struct super_block * sb, const unsigned int len);

/* ==================================================================== */

static int initialize_proc(struct task_struct *p);
static char * xx_d_path(struct task_struct *task,
                        struct dentry *dentry,
                        struct vfsmount *vfsmnt,
                        char *buf,
                        int buflen);

/* ==================================================================== */

// xxxxxxx need to fix it to allow for mount points
/* Copied from selinux/avc.c with no changes which was
 * Copied from fs/dcache.c:d_path and hacked up to
 * avoid need for vfsmnt, root, and rootmnt parameters.
 * Build up full path of dentry's filename 
 */

char *
get_dentry_pathname(struct dentry *dentry, 
                    char *buffer,
                    int buflen)
{
	char * end = buffer+buflen;
	char * retval;
	int namelen;

	*--end = '\0';
	buflen--;

	if (!IS_ROOT(dentry) && d_unhashed(dentry)) {
		buflen -= 10;
		end -= 10;
		memcpy(end, " (deleted)", 10);
	}

	/* Get '/' right */
	retval = end-1;
	*retval = '/';

	for (;;) {
		struct dentry * parent;
		if (IS_ROOT(dentry)) {
			goto global_root;
		}
		parent = dentry->d_parent;
		namelen = dentry->d_name.len;
		if (!namelen)
			goto skip;
		buflen -= namelen + 1;
		if (buflen < 0)
			break;
		end -= namelen;
		memcpy(end, dentry->d_name.name, namelen);
		*--end = '/';
		retval = end;
skip:
		dentry = parent;
		if (!dentry)
			break;
	}
	return retval;
	
global_root:
	namelen = dentry->d_name.len;
	buflen -= namelen;
	if (buflen >= 0) {
		retval -= namelen-1;	/* hit the slash */
		memcpy(retval, dentry->d_name.name, namelen);
	}
	// Now add the mount point path name (if any)
	if (dentry->d_sb->s_security != NULL) {
		namelen = strlen((char *)dentry->d_sb->s_security);
		if (namelen > 0) {
			buflen -= namelen;
			if (buflen >= 0) {
				if (*(retval + 1) != '\0') {
					retval -= namelen;
				} else {
					retval -= namelen - 1;
				}
				memcpy(retval,
				       (char *)dentry->d_sb->s_security,
				       namelen);
			}
		}
	}
	
	return retval;
}


void
get_dentry_lattr(struct dentry *dentry, lattr_t * lattr) 
{
	char *name = NULL;
	//	char buf[PAGE_SIZE];
	char buf[LOMAC_MAX_PATH_LEN];

	name = get_dentry_pathname(dentry, buf, LOMAC_MAX_PATH_LEN);
	lomac_plm_lookup_name(name, lattr);

	return;
}

//
// Lifted from linux/sched.h "d_path" with parameter "task" added (which
// replaced "current" from the sched.h version
//
//static inline char * xx_d_path(struct task_struct *task,
static char * xx_d_path(struct task_struct *task,
                        struct dentry *dentry,
                        struct vfsmount *vfsmnt,
                        char *buf,
                        int buflen)
{
	char *res;
	struct vfsmount *rootmnt;
	struct dentry *root;
	
	read_lock(&task->fs->lock);
	rootmnt = mntget(task->fs->rootmnt);
	root = dget(task->fs->root);
	read_unlock(&task->fs->lock);
	spin_lock(&dcache_lock);
	res = d_path(dentry, vfsmnt, buf, buflen);
	spin_unlock(&dcache_lock);
	dput(root);
	mntput(rootmnt);
	return res;
}


        // name = get_task_pathname(p, buf, PAGE_SIZE);

//can we do something similar for inodes or files or dentry?
//inode->i_mmap is a vm_area_struct
//the args to xx_d_path come from file
//and then there is p -- we need to do something for mount stuff

char *
get_task_pathname(struct task_struct *p,
                  char *buf,
                  int buflen)
{
	char *s;

	s = NULL;
	if (p->mm) {
		struct vm_area_struct *vma = p->mm->mmap;

		while (vma) {
			if ((vma->vm_flags & VM_EXECUTABLE) && 
			    vma->vm_file) {
				s = xx_d_path(p,
					      vma->vm_file->f_dentry,
					      vma->vm_file->f_vfsmnt,
					      buf,
					      buflen);
				break;
			}
			vma = vma->vm_next;
		}
	}
            
	return s;
}


char *
get_inode_pathname(struct inode *i,
                   char *buf,
                   int buflen) {
	char *s = NULL;
	struct dentry *dentry;

	dentry = d_find_alias(i);
	if (dentry == NULL
	    && i->i_sb->s_root->d_inode == i) {
		dentry = i->i_sb->s_root;
	}
			
	if (dentry) {
		s = get_dentry_pathname(dentry, 
					buf,
					buflen);
	}
	
	return s;
}

char *
get_inode_name(struct inode *i,
               char *buf,
               int buflen)
{
	char *s = NULL;
	struct dentry *dentry;

	dentry = d_find_alias(i);

	if (dentry) {
		s = buf;
		memcpy(s, dentry->d_name.name, dentry->d_name.len);
		buf[dentry->d_name.len] = '\0';
	}

	return s;
}

/* ==================================================================== */

static void
initialize_inode(char *name, struct inode *ino)
{
#ifdef LOMAC_DEBUG 
	struct lomac_node *inode_sec = (struct lomac_node *)ino->i_security;
#endif
	int err;
#ifdef LOMAC_DEBUG
	if(inode_sec == NULL)
	  PDEBUG("initialize_inode: i_security not set\n");
#endif
	err = lomac_plm_lookup_inode(name, ino);
	if (err) {
		PDEBUG("initialize_inode: error looking up %s", name);
	}
#ifdef LOMAC_DEBUG
	if(inode_sec->ln_flags == 0)
	  PDEBUG("initialize_inode: not initialized");
	
	if(!(IS_LN_VALID_LEVEL(inode_sec->ln_level)))
	  PDEBUG("invalid leven");
	if(!IS_LN_VALID_FLAGS((inode_sec->ln_flags)))
	  PDEBUG("invalid flags\n");
#endif		
	return;
}


static int
initialize_proc(struct task_struct *p)
{
	lattr_t high_lattr = { LOMAC_HIGHEST_LEVEL, 0 };
	lattr_t lattr;
	char *currname;
	//	char buf[PAGE_SIZE];
	char buf[LOMAC_MAX_PATH_LEN];
	int err = 0;

	currname = get_task_pathname(p, buf, LOMAC_MAX_PATH_LEN);
	if (currname != NULL) {
//		PDEBUG("%5d %s\t", p->pid, currname);
		err = lomac_plm_lookup_name(currname, &lattr);
		if (lattr.level == LOMAC_SUBJ_LEVEL) {
			lattr = high_lattr;
		}
	} else {
//		PDEBUG("%5d [%s]\t", p->pid, p->comm);
		// This is a kernel thread, just set everything high
		lattr = high_lattr;
	}

	if (err) {
		return err;
	}
	
	init_subject_lattr((lomac_subject_t *)p, &lattr);
	if (p->security == NULL) {
		return -ENOMEM;
	}
	
	return 0;
}


int
lomac_initialize_sb(struct super_block * sb,
		    const char * mount_point,
		    const unsigned int len) 
{
	int error;
	char * sb_sec;

	if (len > 0) {
		// Also need space for leading '/' and trailing '\0'
		error = sb_alloc_security(sb, len + 2);
		if (error) {
			PDEBUG("lomac ini sb: alloc security error\n");
			return error;
		}

		sb_sec = (char *)sb->s_security;

		*sb_sec = '/';
		memcpy(sb_sec + 1, mount_point, len);
		sb_sec[len + 1] = '\0';
	}

	return 0;
}


int
lomac_initialize_pipe(struct inode * inode) 
{
	int error;
	lomac_object_t lobj;
	lattr_t lattr;

	error = inode_alloc_security(inode);
	if (error) {
		PDEBUG("lomac init: alloc security error\n");
		return error;
	}
	lobj.lo_type = LO_TYPE_INODE;
	lobj.lo_object.inode = inode;

	lattr.level = LOMAC_HIGHEST_LEVEL;
	lattr.flags = 0;
	set_object_lattr(&lobj, lattr);

	return 0;
}


int
lomac_initialize_socket(struct inode * inode) 
{
	int error;
	lomac_object_t lobj;
	lattr_t lattr;
	char name[LOMAC_MAX_PATH_LEN];
	struct sock *s;

	struct socket *sockt, *pairsock;
	struct inode *pairino;

	error = inode_alloc_security(inode);
	if (error) {
		PDEBUG("lomac init: alloc security error\n");
		return error;
	}

	// Default initializations -- they may be changed in code
	lobj.lo_type = LO_TYPE_INODE;
	lobj.lo_object.inode = inode;

	lattr.level = LOMAC_LOWEST_LEVEL;
	lattr.flags = 0;

	sockt = SOCKET_I(inode);
	s = sockt->sk;
	if (s->sk_family == AF_UNIX) {
		if (unix_sk(s)->addr != NULL) {
			// There is a name
			strcpy(name,
			       unix_sk(s)->addr->name->sun_path);
			lomac_plm_lookup_name(name, &lattr);
		} else {
			// There is no name
			if (s->sk_pair
			    && unix_sk(s->sk_pair)->addr != NULL) {
				// There is the other side of the pair
				if (s->sk_pair->sk_socket
				    && SOCK_INODE(s->sk_pair->sk_socket)){
				  pairsock = s->sk_pair->sk_socket;
				  pairino = SOCK_INODE(pairsock); 
				    if(pairino->i_security) 
				{
					// Already set on pair, so use it
					lobj.lo_object.inode = SOCK_INODE(s->sk_pair->sk_socket);
					get_object_lattr(&lobj, &lattr);
					lobj.lo_object.inode = inode;
				}
			}
		}
	}
	}

	set_object_lattr(&lobj, lattr);

	return 0;
}


int
lomac_initialize_procs(void)
{
	int error;
	struct task_struct *p, *g;

	read_lock(&tasklist_lock);
	do_each_thread(g,p) {
		error = initialize_proc(p);
		if (error) {
			read_unlock(&tasklist_lock);
			return error;
		} 
	}while_each_thread(g,p);
	read_unlock(&tasklist_lock);

	return 0;
}


int sb_alloc_security (struct super_block * sb, const unsigned int len)
{
	if (sb->s_security != NULL) {
		return 0;
	}
    
	sb->s_security = kmalloc(len, GFP_KERNEL);
	if (sb->s_security == NULL) {
		return -ENOMEM;
	}

	return 0;
}


int inode_alloc_security (struct inode *inode)
{
	struct lomac_node *inode_sec;

	if (inode->i_security != NULL) {
		return 0;
	}
    
	inode->i_security = kmalloc(sizeof(struct lomac_node), GFP_KERNEL);
	if (inode->i_security == NULL) {
		return -ENOMEM;
	}

	inode_sec = (struct lomac_node *)inode->i_security;
	inode_sec->ln_vp = NULL;
	inode_sec->ln_lowervp = NULL;
	inode_sec->ln_flags = 0;
	
	inode_sec->ln_underpolicy = NULL;
	inode_sec->ln_entry = NULL;
#if defined(LOMAC_DEBUG_INCNAME)
	inode_sec->ln_name[0] = '\0';	/* final component name */
#endif

	return 0;
}

//xxxxxxx dcache_lock ???
/* Taken from dte/module.c (dte_walk_dcache_tree_full() */
/*   -- printk's changed to PDEBUG's */
/*      obvious dte-isms removed or changed */
/* a version of walk_dcache_tree which also crosses mounts */
/* it's called only at dte init, so it also sets up the superblocks */
void lomac_initialize_inodes(struct vfsmount *pmnt,
			     struct dentry *parent,
			     struct vfsmount *rootmnt)
{
	struct dentry *this_parent = parent;
	struct vfsmount *mnt;
	struct list_head *next;
	char buf[LOMAC_MAX_PATH_LEN];
	char *name = NULL;
	int err;

	/*
	 * check for external attributes file
	 * handle the 'true parent' hookups
	 */

repeat:
	next = this_parent->d_subdirs.next;
resume:
	while (next != &this_parent->d_subdirs) {
		struct list_head *tmp = next;
		struct dentry *dentry = list_entry(tmp, struct dentry, d_child);

		next = tmp->next;
		
		if (dentry->d_inode) {
			KERNEL_ASSERT("multiple inodes",
				      dentry->d_inode->i_list.next != dentry->d_inode->i_list.prev);
			if (IS_ROOT(dentry) || !list_empty(&dentry->d_hash)) {
				err = inode_alloc_security(dentry->d_inode);
				if (err) {
					PDEBUG("lomac_initialize_inodes: can not alloc");
					continue;
				}
				
				name = d_path(dentry,
						pmnt,
						buf, LOMAC_MAX_PATH_LEN);

				initialize_inode(name, dentry->d_inode);
			} else {
				continue;
			}
		}
		if (dentry->d_mounted) {
			mnt = lookup_mnt(pmnt, dentry);
			/* if it's a bind or we've already assigned this fs, skip */
			if (mnt && !mnt->mnt_root->d_inode->i_security &&
					mnt->mnt_root == mnt->mnt_sb->s_root) {
				
				name = d_path(mnt->mnt_root,
						mnt,
						buf, LOMAC_MAX_PATH_LEN);
				
				err = inode_alloc_security(mnt->mnt_root->d_inode);
				if (err) {
					PDEBUG("lomac_initialize_inodes: can not alloc");
					continue;
				}
					
				initialize_inode(name, mnt->mnt_root->d_inode);
				lomac_initialize_sb(mnt->mnt_sb,
						    dentry->d_name.name,
						    dentry->d_name.len);
				lomac_initialize_inodes(mnt, mnt->mnt_root, pmnt);
			} else if (mnt) {
				PDEBUG("lomac_initialize_inodes: not descending %s\n",
						mnt->mnt_devname);
				if (mnt->mnt_root->d_inode->i_security) {
					PDEBUG("lomac_initialize_inodes: i_sec set for %s\n",
							mnt->mnt_devname);
				}
				if (mnt->mnt_root != mnt->mnt_sb->s_root) {
					PDEBUG("lomac_initialize_inodes: s_root!=mnt_root,%s\n",
							mnt->mnt_devname);
				}
			} else {
				PDEBUG("lomac_initialize_inodes: no mnt under %s,%s\n",
						pmnt->mnt_devname, dentry->d_iname);
			}
			if(mnt)
			  mntput(mnt);
		}
		if (!list_empty(&dentry->d_subdirs)) {
			this_parent = dentry;
			goto repeat;
		}
	}
	/*
	 * All done at this level ... ascend and resume the search.
	 */
	if (this_parent != parent) {
		next = this_parent->d_child.next;
		this_parent = this_parent->d_parent;
		goto resume;
	}
/*	spin_unlock(&dcache_lock);*/
}

int do_getxattr(struct inode *inode, struct dentry *dentry, lattr_t *lattr)
{
  int len;
  int rc;

  len = inode->i_op->getxattr(dentry, LOMAC_XATTR_NAME, NULL, 0);
  if(len<0){
    return 0;
  }

  rc = inode->i_op->getxattr(dentry, LOMAC_XATTR_NAME, lattr, len);

  return rc;

}


void do_setxattr(struct inode *inode, struct dentry *dentry)
{
  int rc;
  lattr_t lattr;

  lomac_object_t lobj;

  lobj.lo_type = LO_TYPE_INODE;
  lobj.lo_object.inode = inode;

  get_object_lattr(&lobj, &lattr);

  down(&inode->i_sem);
  rc = inode->i_op->setxattr(dentry, LOMAC_XATTR_NAME, &lattr, sizeof(lattr_t),0);
  up(&inode->i_sem);

}

void do_setxattr_value(struct inode *inode, struct dentry *dentry, lattr_t * lattr)
{
  int rc;

  down(&inode->i_sem);
  rc = inode->i_op->setxattr(dentry, LOMAC_XATTR_NAME, lattr, sizeof(lattr_t),0);
  up(&inode->i_sem);

}
