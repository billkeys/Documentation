#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

#undef unix
struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = __stringify(KBUILD_MODNAME),
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
};

static const struct modversion_info ____versions[]
__attribute_used__
__attribute__((section("__versions"))) = {
	{        0, "cleanup_module" },
	{        0, "init_module" },
	{        0, "struct_module" },
	{        0, "d_path" },
	{        0, "__kmalloc" },
	{        0, "__mntput" },
	{        0, "mod_reg_security" },
	{        0, "malloc_sizes" },
	{        0, "next_thread" },
	{        0, "dput" },
	{        0, "unregister_security" },
	{        0, "d_find_alias" },
	{        0, "sprintf" },
	{        0, "printk" },
	{        0, "panic" },
	{        0, "copy_to_user" },
	{        0, "preempt_schedule" },
	{        0, "path_release" },
	{        0, "mod_unreg_security" },
	{        0, "init_task" },
	{        0, "kmem_cache_alloc" },
	{        0, "path_lookup" },
	{        0, "lookup_mnt" },
	{        0, "kfree" },
	{        0, "memcpy" },
	{        0, "__up_wakeup" },
	{        0, "find_task_by_pid" },
	{        0, "__down_failed" },
	{        0, "copy_from_user" },
	{        0, "register_security" },
};

static const char __module_depends[]
__attribute_used__
__attribute__((section(".modinfo"))) =
"depends=";

