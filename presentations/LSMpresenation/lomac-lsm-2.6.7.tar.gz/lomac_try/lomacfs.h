/*-
 * Copyright (c) 2005 Panasonic Corporation of North America
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *
 * Copyright (c) 2001 Networks Associates Technology, Inc.
 * All rights reserved.
 *
 * This software was developed for the FreeBSD Project by NAI Labs, the
 * Security Research Division of Network Associates, Inc. under
 * DARPA/SPAWAR contract N66001-01-C-8035 ("CBOSS"), as part of the DARPA
 * CHATS research program.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * $Id$
 * $FreeBSD: src/sys/security/lomac/lomacfs.h,v 1.2 2002/03/13 22:55:20 rwatson Exp $
 */

#ifndef LOMACFS_H
#define LOMACFS_H

#include <linux/types.h>

#include <linux/list.h>

#define	LN_LEVEL_MASK		0x0003
#define	LN_LOWEST_LEVEL		0x0001
#define	LN_SUBJ_LEVEL		0x0002	/* placeholder before inheriting */
#define	LN_HIGHEST_LEVEL	0x0003

#define	LN_INHERIT_MASK		0x001c
#define	LN_INHERIT_LOW		0x0004	/* children start with a low level */
#define	LN_INHERIT_HIGH		0x0008	/* children start with a high level */
#define	LN_INHERIT_SUBJ		0x0010	/* children inherit subject's level */

#define	LN_ATTR_MASK		0x03e0
#define	LN_ATTR_LOWWRITE	0x0020	/* lower levels may write to */
#define	LN_ATTR_LOWNOOPEN	0x0040	/* NOT USED lower levels may not open */
#define	LN_ATTR_NONETDEMOTE	0x0080	/* will not demote on net read */
#define	LN_ATTR_NODEMOTE	0x0100	/* subject won't demote on other read */
#define LN_ATTR_LOWMAYOPEN	0x0200	/* lower levels may open */

#define	LN_CHILD_ATTR_SHIFT		4   /* lshift from attr -> child attr */
#define	LN_CHILD_ATTR_MASK	    0x3e00
#define	LN_CHILD_ATTR_LOWWRITE	    0x0200  /* lower levels may write to */
#define	LN_CHILD_ATTR_LOWNOOPEN	    0x0400  /* NOT USED */
#define	LN_CHILD_ATTR_NONETDEMOTE   0x0800  /* will not demote on net read */
#define	LN_CHILD_ATTR_NODEMOTE      0x1000  /* no subj demote on other read */
#define	LN_CHILD_ATTR_LOWMAYOPEN    0x2000  /* lower levels may open */


#define IS_LN_VALID_LEVEL(l) ((((l) & LN_LEVEL_MASK) <= LN_HIGHEST_LEVEL) && (((l) & LN_LEVEL_MASK) >= LN_LOWEST_LEVEL))
#define IS_LN_VALID_FLAGS(f) (((f) & ~(LN_LEVEL_MASK | LN_INHERIT_MASK | LN_ATTR_MASK | LN_CHILD_ATTR_MASK)) == 0)

/*
 * This is the "placeholder" structure initialized from the PLM that
 * holds the level information for all named objects.
 */
struct lomac_node_entry {
	struct list_head    ln_children;
	struct list_head    ln_chain;
	u_int               ln_flags;
	char                *ln_name;   /* last component name (to search) */
	const char          *ln_path;	/* in "stable" storage */
};

/*
 * This is the structure associated with i_security on all inodes.
 */
struct lomac_node {
	struct inode *ln_vp;		/* inode back-pointer */
	struct inode *ln_lowervp;	/* shadowed inode (ref'd or NULL) */
	u_int	ln_flags;
	/* What's the last node explicitly specifying policy for this? */
	struct lomac_node_entry *ln_underpolicy;
	/* If non-NULL, this corresponds 1:1 to a specific PLM node entry. */
	struct lomac_node_entry *ln_entry;
#if defined(LOMAC_DEBUG_INCNAME)
	char	ln_name[MAXPATHLEN];	/* final component name */
#endif
};


#endif /* LOMACFS_H */
