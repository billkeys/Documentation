/*
 * Copyright (c) 2005 Panasonic Corporation of North America
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *
*/

#include <linux/file.h>
#include <linux/mm.h>
#include <linux/pagemap.h>
#include <linux/swap.h>
#include <linux/skbuff.h>
#include <linux/netlink.h>
#include <linux/ptrace.h>
#include <linux/socket.h>
#include <linux/un.h>

#include <linux/config.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/security.h>
#include <linux/netfilter.h>
#include <linux/netlink.h>
#include <linux/init.h>
#include <asm/uaccess.h>
#include <linux/smp_lock.h>
#include <linux/version.h>
#include <linux/kgdb.h>
#include <linux/mount.h>
#include <linux/namei.h>
#include <linux/pipe_fs_i.h>
#include <net/sock.h>
#include <net/af_unix.h>
#include <asm/mman.h>

#include "lomac.h"
#include "kernel_interface.h"
#include "kernel_mediate.h"
#include "kernel_monitor.h"
#include "kernel_plm.h"
#include "kernel_util.h"
#include "lomacfs.h"
#include "lomacio.h"		// For the "sys_security" calls
#ifdef LOMACFS1
#include "lomacfs1.h"
#endif	// LOMACFS1

static void __exit lomac_exit (void);

static int secondary;

static int lomac_ptrace (struct task_struct *parent, struct task_struct *child)
{
	return 0;
}

static int lomac_capget (struct task_struct *target, kernel_cap_t * effective,
			 kernel_cap_t * inheritable, kernel_cap_t * permitted)
{
	return 0;
}

static int lomac_capset_check (struct task_struct *target,
			       kernel_cap_t * effective,
			       kernel_cap_t * inheritable,
			       kernel_cap_t * permitted)
{
	return 0;
}

static void lomac_capset_set (struct task_struct *target,
			      kernel_cap_t * effective,
			      kernel_cap_t * inheritable,
			      kernel_cap_t * permitted)
{
	return;
}

static int lomac_acct (struct file *file)
{
	return 0;
}

static int lomac_capable (struct task_struct *tsk, int cap)
{
	if (cap_is_fs_cap (cap) ? tsk->fsuid == 0 : tsk->euid == 0)
		/* capability granted */
		return 0;

	/* capability denied */
	return -EPERM;
}

static int lomac_sysctl (ctl_table * table, int op)
{
	return 0;
}

static int lomac_get_proc_level(void *data)
{
	struct lomac_proc_struct sp;
	struct task_struct *p;
	lattr_t *task_sec;
    
	if (copy_from_user(&sp, data, sizeof(struct lomac_proc_struct))) {
		return -EFAULT;
	}

	p = find_task_by_pid(sp.pid);
	if (!p) {
		return -ESRCH;
	}

	task_sec = (lattr_t *)p->security;
	if (task_sec == NULL) {
		return -EFAULT;
	}

	sp.level = task_sec->level;
	sp.flags = task_sec->flags;

	if (copy_to_user(data, &sp, sizeof(struct lomac_proc_struct))) {
		return -EFAULT;
	}

	return 0;
}

static int lomac_make_proc_low(void *data)
{
	struct lomac_proc_struct sp;
	struct task_struct *p;
	lattr_t lattr;
    
	if (copy_from_user(&sp, data, sizeof(struct lomac_proc_struct))) {
		return -EFAULT;
	}

	p = find_task_by_pid(sp.pid);
	if (!p) {
		return -ESRCH;
	}

	lattr.level = LOMAC_LOWEST_LEVEL;
	lattr.flags = 0;

	task_lock(p);
	set_subject_lattr(p, lattr);
	task_unlock(p);

	return 0;
}

static int lomac_set_proc_level(void *data)
{
	struct lomac_proc_struct sl;
	struct task_struct *p;
	lattr_t lattr;
	lattr_t *task_sec;
    
	if (copy_from_user(&sl, data, sizeof(struct lomac_proc_struct))) {
		return -EFAULT;
	}

	p = find_task_by_pid(sl.pid);
	if (!p) {
		return -ESRCH;
	}

	lattr.level = sl.level;
	task_sec = (lattr_t *)p->security;
	if (task_sec != NULL) {
		lattr.flags = task_sec->flags;
	}
	else {
		lattr.flags = 0;
	}
    
	task_lock(p);
	set_subject_lattr(p, lattr);
	task_unlock(p);

	return 0;
}

static int lomac_get_file_level(void *data)
{
	struct lomac_file_struct sf;
	struct nameidata nd;
	struct lomac_node *s;
	lomac_object_t lobj;
	lattr_t lattr;
	long err;
   
	if (copy_from_user(&sf, data, sizeof(struct lomac_file_struct))) {
		return -EFAULT;
	}

	err = path_lookup(sf.filename, LOOKUP_FOLLOW, &nd);
	if (err) {
			return err;
	}
	
	if (!nd.dentry->d_inode) {
		path_release(&nd);
		return -ENOENT;
	}
		
	s = (struct lomac_node *) nd.dentry->d_inode->i_security;
	if (!s) {
		path_release(&nd);
		return -ENOENT;
	}
	
	err = 0;
	lobj.lo_type = LO_TYPE_INODE;
	lobj.lo_object.inode = nd.dentry->d_inode;
	get_object_lattr(&lobj, &lattr);

	sf.level = (lattr.level == LOMAC_SUBJ_LEVEL)
		? ((lattr_t *) current->security)->level
		: lattr.level;
	sf.flags = lattr.flags;

	if (copy_to_user(data, &sf, sizeof(struct lomac_file_struct))) {
		return -EFAULT;
	}

	path_release(&nd);
	return err;

	return 0;
}

static int lomac_quotactl (int cmds, int type, int id, struct super_block *sb)
{
	return 0;
}

static int lomac_quota_on (struct file *f)
{
	return 0;
}

static int lomac_syslog (int type)
{
	return 0;
}

static int lomac_vm_enough_memory(long pages)
{
	return 0;
}

static void lomac_sb_free_security (struct super_block *sb)
{
	PDEBUG("lomac_sb_free_security\n");

	if (sb->s_security) {
		kfree(sb->s_security);
		sb->s_security = NULL;
	}

	return;
}

static int lomac_sb_copy_data (struct file_system_type *type,
			       void *orig, void *copy)
{
	return 0;
}

static int lomac_sb_kern_mount (struct super_block *sb, void *data)
{
	return 0;
}

static int lomac_sb_statfs (struct super_block *sb)
{
	return 0;
}

static void lomac_sb_post_remount (struct vfsmount *mnt, unsigned long flags,
				   void *data)
{
	return;
}

static int lomac_inode_alloc_security (struct inode *inode)
{
//	PDEBUG("lomac_inode_alloc__security\n");
	return inode_alloc_security(inode);
}

static void lomac_inode_free_security (struct inode *inode)
{
//	PDEBUG("lomac_inode_free_security\n");

	if (inode->i_security) {
		kfree(inode->i_security);
		inode->i_security = NULL;
	}

	return;
}

static int lomac_inode_create (struct inode *inode, struct dentry *dentry,
			       int mask)
{
	lomac_object_t lobj = {LO_TYPE_INODE, {inode}};
	int retval;
	lattr_t lattr;

//	PDEBUG("lomac_inode_create: %s\n", dentry->d_name.name);
	retval = lomac_plm_lookup_inode_and_name(inode,
						 dentry->d_name.name,
						 dentry->d_name.len,
						 &lattr);
	if (retval) {
		return retval;
	}

	if(mediate_subject_level_object("create",
					 current,
					 &lattr,
					 dentry->d_name.name,
					 &lobj)) {
		return 0;
	} else {
		return -EPERM;
	}

	return 0;
}

static void lomac_inode_post_create (struct inode *inode, struct dentry *dentry,
				     int mask)
{

	struct lomac_node * ln;
	int err;

	char buf[LOMAC_MAX_PATH_LEN];
	char *name;
	lattr_t obj_lattr;
	lomac_object_t lobj;

//	PDEBUG("lomac_inode_post_create: %s\n", dentry->d_name.name);
	if (dentry->d_inode == NULL) {
		return;
	}

	if(current->security == NULL)
	  printk("lomac_inode_post_create: no task security\n");
	if(inode->i_security == NULL)
	  PDEBUG("lomac_inode_post_create: no i_security\n");
	err = inode_alloc_security(dentry->d_inode);
	if (err) {
		PDEBUG("lomac_inode_post_create: alloc security error\n");
		return;
	}

	ln = (struct lomac_node *)inode->i_security;
	if(!(ln->ln_vp != NULL
	     || ln->ln_lowervp != NULL
	     || ln->ln_flags != 0
	     || ln->ln_underpolicy != NULL
	     || ln->ln_entry != NULL))
	  PDEBUG("lomac_inode_post_create: security not set for parent\n");
  
	if((ln->ln_vp == NULL
	     && ln->ln_lowervp == NULL
	     && ln->ln_underpolicy == NULL
	    && ln->ln_entry == NULL)){
	  name = get_dentry_pathname(dentry, buf, LOMAC_MAX_PATH_LEN);

	  lomac_plm_lookup_name(name, &obj_lattr);
	  lobj.lo_type = LO_TYPE_INODE;
	  lobj.lo_object.inode = dentry->d_inode;

	  set_object_lattr(&lobj, obj_lattr);
	  
	  return;

	}else{

	lomac_plm_init_lomacfs_inode(inode,
				     dentry->d_inode,
				     &dentry->d_name,
				     current->security);

	if(inode->i_op->setxattr)
	  do_setxattr(dentry->d_inode, dentry);
	}

	return;
}

static int lomac_inode_link (struct dentry *old_dentry, struct inode *inode,
			     struct dentry *new_dentry)
{

	lattr_t old_obj_lattr;
	lattr_t new_obj_lattr;
	lomac_object_t old_obj;

//	PDEBUG("lomac_inode_link: old %s   new %s\n",
//	       old_dentry->d_name.name, new_dentry->d_name.name);

	if(old_dentry->d_inode == NULL)
	  PDEBUG("lomac_inode_link: no inode for old dentry\n");

	get_dentry_lattr(old_dentry, &old_obj_lattr);
	if (old_obj_lattr.level == LOMAC_SUBJ_LEVEL) {
		old_obj_lattr.level = ((lattr_t *)current->security)->level;
	}
	get_dentry_lattr(new_dentry, &new_obj_lattr);
	if (new_obj_lattr.level == LOMAC_SUBJ_LEVEL) {
		new_obj_lattr.level = ((lattr_t *)current->security)->level;
	}
	
	old_obj.lo_type = LO_TYPE_INODE;
	old_obj.lo_object.inode = old_dentry->d_inode;

	if (new_obj_lattr.level == old_obj_lattr.level
	    && mediate_subject_level_object("link",
					    current,
					    &new_obj_lattr,
					    new_dentry->d_name.name,
					    &old_obj)) {
		return 0;
	} else {
		return -EPERM;
	}

	return 0;
}

static void lomac_inode_post_link (struct dentry *old_dentry,
				   struct inode *inode,
				   struct dentry *new_dentry)
{
	return;
}

static int lomac_inode_unlink (struct inode *inode, struct dentry *dentry)
{

	lomac_object_t lobj;
	lattr_t lattr;
	int retval;
	
//	PDEBUG("lomac_inode_unlink: %s\n", dentry->d_name.name);

	if(dentry->d_inode == NULL)
	  PDEBUG("lomac_inode_unlink: no inode for dentry\n");
	retval = lomac_plm_lookup_inode_and_name(inode,
						 dentry->d_name.name,
						 dentry->d_name.len,
						 &lattr);
	if (retval) {
		return retval;
	}

	lobj.lo_type = LO_TYPE_INODE;
	lobj.lo_object.inode = dentry->d_inode;
	
	if(mediate_subject_level_object("unlink",
					 current,
					 &lattr,
					 dentry->d_name.name,
					 &lobj)) {
		return 0;
	} else {
		return -EPERM;
	}

	return 0;
}

static int lomac_inode_symlink (struct inode *inode, struct dentry *dentry,
				const char *orig_name)
{

	lattr_t orig_obj_lattr;
	lattr_t symlink_obj_lattr;
	lomac_object_t symlink_obj;
	int retval;

//	PDEBUG("lomac_inode_symlink: %s   %s\n", dentry->d_name.name, name);

	retval = lomac_plm_lookup_inode_and_name(inode,
						 dentry->d_name.name,
						 dentry->d_name.len,
						 &symlink_obj_lattr);
	if (retval) {
		return retval;
	}
	if (symlink_obj_lattr.level == LOMAC_SUBJ_LEVEL) {
		symlink_obj_lattr.level = ((lattr_t *)current->security)->level;
	}
	
	retval = lomac_plm_lookup_inode_and_name(NULL,
						 orig_name,
						 strlen(orig_name),
						 &orig_obj_lattr);
	if (retval) {
		return retval;
	}
	if (orig_obj_lattr.level == LOMAC_SUBJ_LEVEL) {
		orig_obj_lattr.level = ((lattr_t *)current->security)->level;
	}

	symlink_obj.lo_type = LO_TYPE_INODE;
	symlink_obj.lo_object.inode = inode;

	if (symlink_obj_lattr.level == orig_obj_lattr.level
	    && mediate_subject_level_object("symlink",
					    current,
					    &symlink_obj_lattr,
					    dentry->d_name.name,
					    &symlink_obj)) {
		return 0;
	} else {
		return -EPERM;
	}

	return 0;
}

static void lomac_inode_post_symlink (struct inode *inode,
				      struct dentry *dentry, const char *name)
{

	struct lomac_node * ln;
	int err;

	lattr_t obj_lattr;
	lomac_object_t lobj;

//	PDEBUG("lomac_inode_post_symlink: %s   %s\n", dentry->d_name.name, name);
	if (dentry->d_inode == NULL) {
		return;
	}

	if(current->security == NULL)
	  PDEBUG("lomac_inode_post_symlink: no task security\n");
	if(inode->i_security == NULL)
	  PDEBUG("lomac_inode_post_symlink: no i_security\n");
	err = inode_alloc_security(dentry->d_inode);
	if (err) {
		PDEBUG("lomac_inode_post_symlink: alloc security error\n");
		return;
	}

	ln = (struct lomac_node *)inode->i_security;
	if(!(ln->ln_vp != NULL
		      || ln->ln_lowervp != NULL
		      || ln->ln_flags != 0
		      || ln->ln_underpolicy != NULL
	     || ln->ln_entry == NULL))
	  PDEBUG("lomac_inode_post_symlink: security not set for parent\n");
  
	if((ln->ln_vp == NULL
	     && ln->ln_lowervp == NULL
	     && ln->ln_underpolicy == NULL
	    && ln->ln_entry == NULL)){
	  get_dentry_lattr(dentry, &obj_lattr);
	  lobj.lo_type = LO_TYPE_INODE;
	  lobj.lo_object.inode = dentry->d_inode;

	  set_object_lattr(&lobj, obj_lattr);
	  
	  return;

	}

	lomac_plm_init_lomacfs_inode(inode,
				     dentry->d_inode,
				     &dentry->d_name,
				     current->security);

	return;
}

static int lomac_inode_mkdir (struct inode *inode, struct dentry *dentry,
			      int mask)
{

	lomac_object_t lobj;
	lattr_t lattr;
	int retval;

//	PDEBUG("lomac_inode_mkdir: %s\n", dentry->d_name.name);

	retval = lomac_plm_lookup_inode_and_name(inode,
						 dentry->d_name.name,
						 dentry->d_name.len,
						 &lattr);
	if (retval) {
		return retval;
	}

	lobj.lo_type = LO_TYPE_INODE;
	lobj.lo_object.inode = inode;
	
	if(mediate_subject_level_object("mkdir",
					 current,
					 &lattr,
					 dentry->d_name.name,
					 &lobj)) {
		return 0;
	} else {
		return -EPERM;
	}

	return 0;
}

static void lomac_inode_post_mkdir (struct inode *inode, struct dentry *dentry,
				    int mask)
{

	lomac_object_t lobj;
	struct lomac_node *ln;
	int err;

	char buf[LOMAC_MAX_PATH_LEN];
	char *name;
	lattr_t obj_lattr;

//	PDEBUG("lomac_inode_post_mkdir: %s\n", dentry->d_name.name);
	if (dentry->d_inode == NULL) {
		return;
	}
	
	// inode is for parent directory
	// dentry is for entry

	if(current->security == NULL)
	  PDEBUG("lomac_inode_post_mkdir: no task security\n");
	if(inode->i_security == NULL)
	  PDEBUG("lomac_inode_post_mkdir: no i_security\n")

	if (dentry->d_inode->i_security == NULL) {
//		PDEBUG("No security object on child inode: %s\n",
//		       d->d_iname);
		err = inode_alloc_security(dentry->d_inode);
		if (err) 
		{
			PDEBUG("lomac_inode_post_mkdir: alloc security error\n");
			return;
		}
	}

	ln = (struct lomac_node *)inode->i_security;
	if(!(ln->ln_vp != NULL
		        || ln->ln_lowervp != NULL
		        || ln->ln_flags != 0
		        || ln->ln_underpolicy != NULL
	     || ln->ln_entry != NULL))
	  PDEBUG("lomac_inode_post_mkdir: security not set for parent\n");

	if((ln->ln_vp == NULL
	     && ln->ln_lowervp == NULL
	     && ln->ln_underpolicy == NULL
	    && ln->ln_entry == NULL)){
	  name = get_dentry_pathname(dentry, buf, LOMAC_MAX_PATH_LEN);

	  lomac_plm_lookup_name(name, &obj_lattr);
	  lobj.lo_type = LO_TYPE_INODE;
	  lobj.lo_object.inode = dentry->d_inode;

	  set_object_lattr(&lobj, obj_lattr);
	  
	}else{
	
	lomac_plm_init_lomacfs_inode(inode,
				     dentry->d_inode,
				     &dentry->d_name,
				     current->security);
	}
	
	lobj.lo_type = LO_TYPE_INODE;
	lobj.lo_object.inode = dentry->d_inode;
	
	monitor_read_object(current, &lobj);

	return;
}

static int lomac_inode_rmdir (struct inode *inode, struct dentry *dentry)
{

	lomac_object_t lobj = {LO_TYPE_INODE, {dentry->d_inode}};
	int retval;
	lattr_t lattr;

//	PDEBUG("lomac_inode_rmdir: %s\n", dentry->d_name.name);

	if(dentry->d_inode == NULL)
	  PDEBUG("lomac_inode_rmdir: no inode for dentry\n");
	retval = lomac_plm_lookup_inode_and_name(inode,
						 dentry->d_name.name,
						 dentry->d_name.len,
						 &lattr);
	if (retval) {
		return retval;
	}
	
	if(mediate_subject_level_object("rmdir",
					 current,
					 &lattr,
					 dentry->d_name.name,
					 &lobj)) {
		return 0;
	} else {
		return -EPERM;
	}

	return 0;
}

static int lomac_inode_mknod (struct inode *inode, struct dentry *dentry,
			      int mode, dev_t dev)
{

	lomac_object_t lobj;
	
//	PDEBUG("lomac_inode_mknod: %s\n", dentry->d_name.name);

	if (dentry->d_inode == NULL) {
		if (S_ISFIFO(mode) || S_ISSOCK(mode)) {
			return 0;
		}
		else if(!mediate_subject_at_level("mknod",
						  current,
						  LOMAC_HIGHEST_LEVEL)) {
			return -EPERM;
		} else {
			return 0;
		}
	}
	
	if(S_ISFIFO(dentry->d_inode->i_mode)) {
		lobj.lo_type = LO_TYPE_INODE;
		lobj.lo_object.inode = dentry->d_inode;
		if(!mediate_subject_object("mknod",current, &lobj)) {
			return -EPERM;
		}
	} else {
		if(!mediate_subject_at_level("mknod",
					     current,
					     LOMAC_HIGHEST_LEVEL)) {
			return -EPERM;
		}
	}

	return 0;
}

static void lomac_inode_post_mknod (struct inode *inode, struct dentry *dentry,
				    int mode, dev_t dev)
{

	struct lomac_node *ln;
	int err;

	char buf[LOMAC_MAX_PATH_LEN];
	char *name;
	lattr_t obj_lattr;
	lomac_object_t lobj;

//	PDEBUG("lomac_inode_post_mknod: %s\n", dentry->d_name.name);

	if (dentry->d_inode == NULL) {
		return;
	}
	
	// inode is for parent directory
	// dentry is for entry

	if(current->security == NULL)
	  PDEBUG("lomac_inode_post_mknod: no task security\n");
	if(inode->i_security == NULL)
	  PDEBUG("lomac_inode_post_mknod: no i_security\n");

	if (dentry->d_inode->i_security == NULL) {
//		PDEBUG("No security object on child inode: %s\n",
//		       d->d_iname);
		err = inode_alloc_security(dentry->d_inode);
		if (err) 
		{
			PDEBUG("lomac_inode_post_mknod: alloc security error\n");
			return;
		}
	}

	ln = (struct lomac_node *)inode->i_security;
	if(!(ln->ln_vp != NULL
		        || ln->ln_lowervp != NULL
		        || ln->ln_flags != 0
		        || ln->ln_underpolicy != NULL
	     || ln->ln_entry != NULL))
	  PDEBUG("lomac_inode_post_mknod: security not set for parent\n");
	
	if((ln->ln_vp == NULL
	     && ln->ln_lowervp == NULL
	     && ln->ln_underpolicy == NULL
	    && ln->ln_entry == NULL)){
	  name = get_dentry_pathname(dentry, buf, LOMAC_MAX_PATH_LEN);

	  lomac_plm_lookup_name(name, &obj_lattr);
	  lobj.lo_type = LO_TYPE_INODE;
	  lobj.lo_object.inode = dentry->d_inode;

	  set_object_lattr(&lobj, obj_lattr);
	  
	  return;

	}

	lomac_plm_init_lomacfs_inode(inode,
				     dentry->d_inode,
				     &dentry->d_name,
				     current->security);

	return;
}

static int lomac_inode_rename (struct inode *old_inode,
			       struct dentry *old_dentry,
			       struct inode *new_inode,
			       struct dentry *new_dentry)
{

	lattr_t old_obj_lattr;
	lattr_t new_obj_lattr;
	lomac_object_t old_obj = {LO_TYPE_INODE, {old_inode}};
	lomac_object_t new_obj = {LO_TYPE_INODE, {new_inode}};

//	PDEBUG("lomac_inode_rename: old %s   new %s\n",
//	       old_dentry->d_name.name, new_dentry->d_name.name);

	if(old_dentry->d_inode->i_op->getxattr){
	    do_getxattr(old_dentry->d_inode, old_dentry, &old_obj_lattr);
	}
	else 	
	get_dentry_lattr(old_dentry, &old_obj_lattr);
	if (old_obj_lattr.level == LOMAC_SUBJ_LEVEL) {
		old_obj_lattr.level = ((lattr_t *)current->security)->level;
	}

	get_dentry_lattr(new_dentry, &new_obj_lattr);
	if (new_obj_lattr.level == LOMAC_SUBJ_LEVEL) {
		new_obj_lattr.level = ((lattr_t *)current->security)->level;
	}

	if(mediate_subject_level_object("rename",
					current,
					&old_obj_lattr,
					old_dentry->d_name.name,
					&old_obj)
	   && mediate_subject_level_object("rename",
					   current,
					   &new_obj_lattr,
					   new_dentry->d_name.name,
					   &new_obj)
	   && new_obj_lattr.level <= old_obj_lattr.level) {
		return 0;
	} else {
		return -EPERM;
	}

	return 0;
}

static void lomac_inode_post_rename (struct inode *old_inode,
				     struct dentry *old_dentry,
				     struct inode *new_inode,
				     struct dentry *new_dentry)
{
//	PDEBUG("lomac_inode_post_rename: old %s   new %s\n",
//	       old_dentry->d_name.name, new_dentry->d_name.name);
	return;
}

static int lomac_inode_readlink (struct dentry *dentry)
{
//	PDEBUG("lomac_inode_readlink: %s\n", dentry->d_name.name);
	return 0;
}

static int lomac_inode_follow_link (struct dentry *dentry,
				    struct nameidata *nameidata)
{
//	PDEBUG("lomac_inode_follow_link: %s\n", dentry->d_name.name);
	return 0;
}

static int lomac_inode_permission (struct inode *inode, int mask, struct nameidata *nd)
{

#ifdef LOMAC_DEBUG
	struct lomac_node *s = inode->i_security;
	if(s == NULL)
	  PDEBUG("lomac_inode_permission: inode has no security\n");
#endif
	lattr_t *ts = current->security;
	lomac_object_t lobj = {LO_TYPE_INODE,{inode}};


	if (ts == NULL) {
		return 0;
	}

	if(mask & MAY_READ){
		if (S_ISFIFO(inode->i_mode)) {
			monitor_read_object(current, &lobj);
		}
		else if (!S_ISSOCK(inode->i_mode)) {
			if(!mediate_subject_object_open(current, &lobj)){
				return -EPERM;
			}
		}
	}

	if(mask & MAY_WRITE) {
		if (!S_ISFIFO(inode->i_mode)
		    && !S_ISSOCK(inode->i_mode)) {
			if(!mediate_subject_object_open(current, &lobj)){
				return -EPERM;
			}
		}
	}

	return 0;
}

static int lomac_inode_getattr (struct vfsmount *mnt, struct dentry *dentry)
{
	return 0;
}

static void lomac_inode_delete (struct inode *ino)
{
	return;
}

static int lomac_inode_setxattr (struct dentry *dentry, char *name, void *value,
				size_t size, int flags)
{
//	PDEBUG("lomac_inode_setxattr: %s\n", dentry->d_name.name);
	if (!strcmp(name, LOMAC_XATTR_NAME)) {
	  lattr_t *lattr = (lattr_t *)value;
	  do_setxattr_value(dentry->d_inode, dentry, lattr);
	}
	return 0;
}

static void lomac_inode_post_setxattr (struct dentry *dentry, char *name, void *value,
				       size_t size, int flags)
{
}

static int lomac_inode_getxattr (struct dentry *dentry, char *name)
{
//	PDEBUG("lomac_inode_getxattr: %s\n", dentry->d_name.name);
  //temporary solution, whenever need a value set it to make sure it's there
	if (!strcmp(name, LOMAC_XATTR_NAME)) {
	  do_setxattr(dentry->d_inode, dentry);
	}
	return 0;
}

#if 0
static int lomac_inode_listxattr (struct dentry *dentry)
{
	return 0;
}
#endif
static int lomac_inode_removexattr (struct dentry *dentry, char *name)
{
	return 0;
}

static int lomac_inode_getsecurity(struct dentry *dentry, const char *name, void *buffer, size_t size)
{
	return 0;
}

static int lomac_inode_setsecurity(struct dentry *dentry, const char *name, const void *value, size_t size, int flags) 
{
	return 0;
}

static int lomac_inode_listsecurity(struct dentry *dentry, char *buffer)
{
        const int len = sizeof(LOMAC_XATTR_NAME);
        if (buffer)
                memcpy(buffer, LOMAC_XATTR_NAME, len);
 	return len;
}

static int lomac_file_permission (struct file *file, int mask)
{

	lomac_object_t lobj;
	struct lomac_node * ln;
	lattr_t lattr;
	
//	PDEBUG("lomac_file_permission: %s\n", file->f_dentry->d_name.name);

	if (file->f_dentry->d_inode == NULL
	    || file->f_dentry->d_inode->i_security == NULL) {
		return 0;
	}
	
	if(current->security == NULL)
	  PDEBUG("lomac_file_permission: task has no security\n");

	ln = (struct lomac_node *)file->f_dentry->d_inode->i_security;
	if (ln->ln_flags == 0
	    && S_ISFIFO(file->f_dentry->d_inode->i_mode)) {
		get_subject_lattr(current, &lattr);
		if (lattr.level == LOMAC_HIGHEST_LEVEL) {
			ln->ln_flags = LN_HIGHEST_LEVEL;
		} else {
			ln->ln_flags = LN_LOWEST_LEVEL;
		}
	}

	lobj.lo_type = LO_TYPE_INODE;
	lobj.lo_object.inode = file->f_dentry->d_inode;

	if(mask & MAY_READ) {
		monitor_read_object(current, &lobj);
	}

	if(mask & MAY_WRITE){
		if (!S_ISFIFO(file->f_dentry->d_inode->i_mode)) {
			if(!mediate_subject_object("file_permission",
						   current,
						   &lobj)) {
				return -EPERM;
			}
		} else {
			if (file->f_dentry->d_sb->s_magic == PIPEFS_MAGIC) {
				// it's an unnamed pipe
				monitor_pipe_write(current, &lobj);
			} else {
				// it's a named pipe
				if(!mediate_subject_object("file_permission",
							   current,
							   &lobj)) {
					return -EPERM;
				}
			}
		}
	}

	return 0;
}

static int lomac_file_alloc_security (struct file *file)
{

	lattr_t *file_sec;

//	PDEBUG("lomac_file_alloc_security\n");
	
	if (file->f_security == NULL) {
		file->f_security = kmalloc(sizeof(lattr_t), GFP_KERNEL);
		if (file->f_security == NULL) {
			return -ENOMEM;
		}

		file_sec = (lattr_t *)file->f_security;
		file_sec->level = LOMAC_NO_LEVEL;
		file_sec->flags = 0;
	}

	return 0;
}

static void lomac_file_free_security (struct file *file)
{
//	PDEBUG("lomac_file_free_security\n");
	if (file->f_security) {
		kfree(file->f_security);
	}

	file->f_security = NULL;

	return;
}

static int lomac_file_ioctl (struct file *file, unsigned int command,
			     unsigned long arg)
{
//	PDEBUG("lomac_file_ioctl: %s\n", file->f_dentry->d_name.name);
	return 0;
}

static int lomac_file_mmap (struct file *file, unsigned long prot,
			    unsigned long flags)
{

        if (file != NULL) {
		lomac_object_t lobj = {LO_TYPE_INODE, {file->f_dentry->d_inode}};
//		PDEBUG("lomac_file_mmap: %s\n", file->f_dentry->d_name.name);
		if(flags & MAP_SHARED && prot & PROT_WRITE &&
		   !mediate_subject_object("mmap", current, &lobj))
			return -EPERM;
		if(prot & PROT_READ)
			monitor_read_object(current, &lobj);
	}
//	else {
//		PDEBUG("lomac_file_mmap: <NULL>\n");
//	}

	return 0;
}

static int lomac_file_mprotect (struct vm_area_struct *vma, unsigned long prot)
{
	return 0;
}

static int lomac_file_lock (struct file *file, unsigned int cmd)
{
	return 0;
}

static int lomac_file_fcntl (struct file *file, unsigned int cmd,
			     unsigned long arg)
{
//	PDEBUG("lomac_file_fcntl: %s\n", file->f_dentry->d_name.name);
	return 0;
}

static int lomac_file_set_fowner (struct file *file)
{
//	PDEBUG("lomac_file_set_fowner: %s\n", file->f_dentry->d_name.name);
	return 0;
}

static int lomac_file_send_sigiotask (struct task_struct *tsk,
				      struct fown_struct *fown, int fd,
				      int reason)
{
//	PDEBUG("lomac_file_send_sigiotask\n");
	return 0;
}

static int lomac_file_receive (struct file *file)
{
//	PDEBUG("lomac_file_receive: %s\n", file->f_dentry->d_name.name);
	return 0;
}

static int lomac_task_create (unsigned long clone_flags)
{
//	PDEBUG("lomac_task_create: curr -- %5d %s\n",
//	       current->pid, currname);

	return 0;
}

static int lomac_task_alloc_security (struct task_struct *p)
{
//	char buf[PAGE_SIZE];
//	char *pname, *currname;
	lattr_t *task_sec;
	lattr_t *curr_sec = (lattr_t *)current->security;

	// Allocate space for security struct in child process
	// current is parent process
    
//	currname = get_task_pathname(current, buf, PAGE_SIZE);
//	PDEBUG("lomac_task_alloc_security: parent -- %5d %s\n",
//	       current->pid, currname);
//	pname = get_task_pathname(p, buf, PAGE_SIZE);
//	PDEBUG("                          child -- %5d %s\n",
//	       p->pid, pname);

	if (p->security == NULL) {
		p->security = kmalloc(sizeof(lattr_t), GFP_KERNEL);
		if (p->security == NULL) {
			return -ENOMEM;
		}
	}

	if(curr_sec == NULL)
	  PDEBUG("lomac_task_alloc_security: no security\n");

	//inherit the security attributes of the parent process
	task_sec = (lattr_t *)p->security;
	task_sec->level = curr_sec->level;
	task_sec->flags = curr_sec->flags;

	return 0;
}

static void lomac_task_free_security (struct task_struct *p)
{

//    char buf[PAGE_SIZE];
//    char *name;
//
//    name = get_task_pathname(p, buf, PAGE_SIZE);
//    PDEBUG("lomac_task_free_security: %s\n", name);
	if (p->security) {
		kfree(p->security);
		p->security = NULL;
	}

	return;
}

static int lomac_task_setuid (uid_t id0, uid_t id1, uid_t id2, int flags)
{
//	PDEBUG("lomac_task_setuid\n");
	return 0;
}

static int lomac_task_post_setuid (uid_t id0, uid_t id1, uid_t id2, int flags)
{
//	PDEBUG("lomac_task_post_setuid\n");
	return 0;
}

static int lomac_task_setgid (gid_t id0, gid_t id1, gid_t id2, int flags)
{
//	PDEBUG("lomac_task_setgid\n");
	return 0;
}

static int lomac_task_setpgid (struct task_struct *p, pid_t pgid)
{
//	char buf[PAGE_SIZE];
//	char *name;

//	name = get_task_pathname(p, buf, PAGE_SIZE);
//	PDEBUG("lomac_task_setpgid  name: %s  pgid: %d pid: %d\n",
//	       name, pgid, p->pid);
	return 0;
}

static int lomac_task_getpgid (struct task_struct *p)
{
//	char buf[PAGE_SIZE];
//	char *name;

//	name = get_task_pathname(p, buf, PAGE_SIZE);
//	PDEBUG("lomac_task_getpgid: %s\n", name);
	return 0;
}

static int lomac_task_getsid (struct task_struct *p)
{
//	PDEBUG("lomac_task_getsid\n");
	return 0;
}

static int lomac_task_setgroups (struct group_info *group_info)
{
//	PDEBUG("lomac_task_setgroups\n");
	return 0;
}

static int lomac_task_setnice (struct task_struct *p, int nice)
{
//	PDEBUG("lomac_task_setnice\n");
	return 0;
}

static int lomac_task_setrlimit (unsigned int resource, struct rlimit *new_rlim)
{
//	PDEBUG("lomac_task_setrlimit\n");
	return 0;
}

static int lomac_task_setscheduler (struct task_struct *p, int policy,
				    struct sched_param *lp)
{
//	PDEBUG("lomac_task_setscheduler\n");
	return 0;
}

static int lomac_task_getscheduler (struct task_struct *p)
{
//	PDEBUG"lomac_task_getscheduler\n");
	return 0;
}

static int lomac_task_wait (struct task_struct *p)
{
//    PDEBUG("lomac_task_wait\n");
	return 0;
}

static int lomac_task_kill (struct task_struct *p, struct siginfo *info,
			    int sig)
{
	lattr_t *curr_sec = (lattr_t *)current->security;

//	PDEBUG("lomac_task_kill:\n");

	/*
	 * Always allow signals to init(8) (necessary to shut down).
	 */
	if (curr_sec == NULL ||
	    p->pid == 1 ||
	    mediate_subject_level_subject("signal",
					  current,
					  curr_sec->level,
					  p)) {
		return 0;
	} else {
		return -EPERM;
	}

	return 0;
}

static int lomac_task_prctl (int option, unsigned long arg2, unsigned long arg3,
			     unsigned long arg4, unsigned long arg5)
{
//	PDEBUG("lomac_task_prctl\n");
	return 0;
}

static void lomac_task_to_inode(struct task_struct *p, struct inode *inode)
{
  lomac_object_t lobj;
  lattr_t lattr;
  lattr_t *curr_sec = (lattr_t *)p->security;
  int err;

  PDEBUG("lomac_task_to_inode\n");
  lobj.lo_type = LO_TYPE_INODE;
  lobj.lo_object.inode = inode;

  lattr.level = curr_sec->level;
  lattr.flags = curr_sec->flags;

  if (inode->i_security == NULL) {
    err = inode_alloc_security(inode);
    if (err) {
      PDEBUG("lomac_task_to_inode: alloc security error\n");
      return;
    }
  }

       set_object_lattr(&lobj, lattr);

  return;

}

static int lomac_ipc_permission (struct kern_ipc_perm *ipcp, short flag)
{
	return 0;
}

static int lomac_msg_msg_alloc_security (struct msg_msg *msg)
{
	return 0;
}

static void lomac_msg_msg_free_security (struct msg_msg *msg)
{
	return;
}

static int lomac_msg_queue_alloc_security (struct msg_queue *msq)
{
	return 0;
}

static void lomac_msg_queue_free_security (struct msg_queue *msq)
{
	return;
}

static int lomac_msg_queue_associate (struct msg_queue *msq, 
				      int msqflg)
{
	return 0;
}

static int lomac_msg_queue_msgctl (struct msg_queue *msq, int cmd)
{
	return 0;
}

static int lomac_msg_queue_msgsnd (struct msg_queue *msq, struct msg_msg *msg,
				   int msgflg)
{
	return 0;
}

static int lomac_msg_queue_msgrcv (struct msg_queue *msq, struct msg_msg *msg,
				   struct task_struct *target, long type,
				   int mode)
{
	return 0;
}

static int lomac_shm_alloc_security (struct shmid_kernel *shp)
{
	return 0;
}

static void lomac_shm_free_security (struct shmid_kernel *shp)
{
	return;
}

static int lomac_shm_associate (struct shmid_kernel *shp, int shmflg)
{
	return 0;
}

static int lomac_shm_shmctl (struct shmid_kernel *shp, int cmd)
{
	return 0;
}

static int lomac_shm_shmat (struct shmid_kernel *shp, char *shmaddr,
			    int shmflg)
{
	lattr_t obj_lattr;
	lomac_object_t lobj;
	char *buf;
	char *ptr;
	int retval;
	
//	PDEBUG("lomac_shm_shmat %s\n", shp->shm_file->f_dentry->d_name.name);
	
	buf = kmalloc(LOMAC_MAX_PATH_LEN, GFP_KERNEL);
	if (buf == NULL) {
		return -ENOMEM;
	}

	ptr = get_dentry_pathname(shp->shm_file->f_dentry, buf, LOMAC_MAX_PATH_LEN);

	lomac_plm_lookup_name(ptr, &obj_lattr);

	lobj.lo_type = LO_TYPE_INODE;
	lobj.lo_object.inode = shp->shm_file->f_dentry->d_inode;
	
	set_object_lattr(&lobj, obj_lattr);

	if (mediate_subject_object("shmat", current, &lobj)) {
		retval = 0;
	} else {
		retval = -EPERM;
	}

	kfree(buf);
	
	return retval;

}

static int lomac_sem_alloc_security (struct sem_array *sma)
{
//	PDEBUG("lomac_sem_alloc_security\n");
	return 0;
}

static void lomac_sem_free_security (struct sem_array *sma)
{
//	PDEBUG("lomac_sem_free_security\n");
	return;
}

static int lomac_sem_associate (struct sem_array *sma, int semflg)
{
//	PDEBUG("lomac_sem_associate\n");
	return 0;
}

static int lomac_sem_semctl (struct sem_array *sma, int cmd)
{
//	PDEBUG("lomac_sem_semctl\n");
	return 0;
}

static int lomac_sem_semop (struct sem_array *sma, 
			    struct sembuf *sops, unsigned nsops, int alter)
{
//	PDEBUG("lomac_sem_semop\n");
	return 0;
}

static int lomac_netlink_send (struct sk_buff *skb)
{
//	PDEBUG("lomac_netlink_send\n");
	if (current->euid == 0)
		cap_raise (NETLINK_CB (skb).eff_cap, CAP_NET_ADMIN);
	else
		NETLINK_CB (skb).eff_cap = 0;

	return 0;
}

static int lomac_netlink_recv (struct sk_buff *skb)
{
//	PDEBUG("lomac_netlink_recv\n");
	if (!cap_raised (NETLINK_CB (skb).eff_cap, CAP_NET_ADMIN))
		return -EPERM;

	return 0;
}

static int lomac_binprm_alloc_security (struct linux_binprm *bprm)
{

	lattr_t *bprm_sec;

//	PDEBUG("lomac_binprm_alloc_security\n");
	bprm->security = kmalloc(sizeof(lattr_t), GFP_KERNEL);
	if (bprm->security == NULL) {
		return -ENOMEM;
	}

	bprm_sec = (lattr_t *)bprm->security;
	bprm_sec->level = LOMAC_NO_LEVEL;
	bprm_sec->flags = 0;

	return 0;
}

static void lomac_binprm_free_security (struct linux_binprm *bprm)
{
//	PDEBUG("lomac_binprm_free_security: %s\n", bprm->filename);
	if (bprm->security) {
		kfree(bprm->security);
		bprm->security = NULL;
	}

	return;
}

static void lomac_binprm_apply_creds (struct linux_binprm *bprm)
{
//	char buf[PAGE_SIZE];
//	char *currname;
	lattr_t *curr_sec = (lattr_t *)current->security;

//	currname = get_task_pathname(current, buf, PAGE_SIZE);
//	PDEBUG("lomac_binprm_compute_creds: %5d %s\n",
//	       current->pid, currname);

	curr_sec = (lattr_t *)bprm->security;

	return;
}

static int lomac_binprm_set_security (struct linux_binprm *bprm)
{
	lattr_t *bprm_sec = (lattr_t *)bprm->security;
	lattr_t *curr_sec = (lattr_t *)current->security;
//	char *currname;
//	char buf[PAGE_SIZE];
	struct lomac_node *ln;	//xxxxxxx
	lomac_object_t lobj = {LO_TYPE_INODE, {bprm->file->f_dentry->d_inode}};
    
//	currname = get_task_pathname(current, buf, PAGE_SIZE);
//	PDEBUG("lomac_binprm_set_security: file--%s  curr--%5d %s\n",
//	       bprm->filename, current->pid, currname);

	if(curr_sec == NULL)
	  PDEBUG("lomac_binprm_set_security: no security\n");

	ln = bprm->file->f_dentry->d_inode->i_security;
	if(ln->ln_flags == 0)
	  PDEBUG("lomac_binprm_set_security: inode security not set\n");
	get_object_lattr(&lobj, bprm_sec);

	if ((curr_sec->level < bprm_sec->level
	     && IS_VALID_LEVEL(curr_sec->level))
	    || bprm_sec->level == LOMAC_SUBJ_LEVEL) {
		bprm_sec->level = curr_sec->level;
	}

	return 0;
}

static int lomac_binprm_check_security (struct linux_binprm *bprm)
{
//	PDEBUG("lomac_binprm_check_security\n");
	return 0;
}

static int lomac_sb_alloc_security (struct super_block *sb)
{
//	PDEBUG("lomac_sb_alloc_security\n");
	return 0;
}

static int lomac_sb_mount (char *dev_name, struct nameidata *nd, char *type,
		       unsigned long flags, void *data)
{
//	PDEBUG("lomac_mount: %s %s\n", dev_name, nd->dentry->d_name.name);
	if(!mediate_subject_at_level("mount", current, LOMAC_HIGHEST_LEVEL)) {
		return -EPERM;
	}

	return 0;
}

static int lomac_sb_check_sb (struct vfsmount *mnt, struct nameidata *nd)
{
	char buf[LOMAC_MAX_PATH_LEN];
	char *path;
	
//	PDEBUG("lomac_sb_check_sb: %s\n", nd->dentry->d_name.name);
	path = get_dentry_pathname(nd->dentry, buf, LOMAC_MAX_PATH_LEN);
      	lomac_initialize_sb(mnt->mnt_sb, path, strlen(path));

	return 0;
}

static int lomac_sb_umount (struct vfsmount *mnt, int flags)
{
//	PDEBUG("lomac_sb_umount\n");
	if(!mediate_subject_at_level("umount", current, LOMAC_HIGHEST_LEVEL)) {
		return -EPERM;
	}

	return 0;
}

static void lomac_sb_umount_close (struct vfsmount *mnt)
{
//	PDEBUG("lomac_sb_umount_close\n");
	return;
}

static void lomac_sb_umount_busy (struct vfsmount *mnt)
{
//	PDEBUG("lomac_sb_umount_busy\n");
	return;
}

static void lomac_sb_post_mountroot (void)
{
//	PDEBUG("lomac_sb_post_mountroot\n");
	return;
}

static void lomac_sb_post_addmount (struct vfsmount *mnt, struct nameidata *nd)
{
//	PDEBUG("lomac_sb_post_addmount\n");
	return;
}

static int lomac_sb_pivotroot (struct nameidata *old_nd, struct nameidata *new_nd)
{
//	PDEBUG("lomac_sb_pivotroot\n");
	return 0;
}

static void lomac_sb_post_pivotroot (struct nameidata *old_nd, struct nameidata *new_nd)
{
//	PDEBUG("lomac_sb_post_pivotroot\n");
	return;
}

static int lomac_inode_setattr (struct dentry *dentry, struct iattr *iattr)
{
//	PDEBUG("lomac_inode_setattr: %s\n", dentry->d_name.name);
	return 0;
}

static void lomac_task_reparent_to_init (struct task_struct *p)
{
//	PDEBUG("lomac_task_reparent_to_init\n");
	p->euid = p->fsuid = 0;
	return;
}

static int lomac_register_security (const char *name, struct security_operations *ops)
{
//	PDEBUG("lomac_register_security\n");
	return -EINVAL;
}

static int lomac_unregister_security (const char *name, struct security_operations *ops)
{
//	PDEBUG("lomac_unregister_security\n");
	return -EINVAL;
}

#ifdef CONFIG_SECURITY_NETWORK
static int lomac_unix_stream_connect (struct socket *sock,
				      struct socket *other,
				      struct sock *newsk)
{
	return 0;
}

static int lomac_unix_may_send (struct socket *sock,
				struct socket *other)
{
	return 0;
}

static int lomac_socket_create (int family, int type, int protocol)
{
//	PDEBUG("lomac_socket_create\n");
	return 0;
}

static void lomac_socket_post_create (struct socket *sock, int family, int type,
				      int protocol)
{
	lattr_t lattr;
	int err;
	lomac_object_t lobj;

	struct inode *s_inode = SOCK_INODE(sock);

//	PDEBUG("lomac_socket_post_create\n");

	if(s_inode->i_security == NULL)
	  PDEBUG("No socket inode security\n");

	if (s_inode->i_security == NULL) {
		err = inode_alloc_security(s_inode);
		if (err) {
			PDEBUG("lomac_socket_post_create: alloc security error\n");
			return;
		}
	}

	lattr.level = LOMAC_LOWEST_LEVEL;
	lattr.flags = 0;
	lobj.lo_type = LO_TYPE_INODE;
	lobj.lo_object.inode = s_inode;
	set_object_lattr(&lobj, lattr);

	return;
}

static int lomac_socket_bind (struct socket *sock, struct sockaddr *address,
			      int addrlen)
{
	char name[LOMAC_MAX_PATH_LEN];
	lattr_t lattr;
	lomac_object_t lobj;

	struct inode *s_inode = SOCK_INODE(sock);
	
//	PDEBUG("lomac_socket_bind\n");

	if(s_inode->i_security == NULL)
	  PDEBUG("lomac_socket_bind: No socket inode security\n");

	if (address->sa_family == AF_UNIX) {
		memcpy(name, address->sa_data, addrlen);
		
		lomac_plm_lookup_name((const char *)name, &lattr);
		
		lobj.lo_type = LO_TYPE_INODE;
		lobj.lo_object.inode = s_inode;
		set_object_lattr(&lobj, lattr);
	}

	lobj.lo_type = LO_TYPE_INODE;
	lobj.lo_object.inode = s_inode;
	if(!mediate_subject_object("bind", current, &lobj)) {
		return -EPERM;
	}

	return 0;
}

static int lomac_socket_connect (struct socket *sock, struct sockaddr *address,
				 int addrlen)
{
	char name[LOMAC_MAX_PATH_LEN];
	lattr_t lattr;
	lomac_object_t lobj;

//	PDEBUG("lomac_socket_connect:\n");
	if (address->sa_family == AF_UNIX) {
		memcpy(name, address->sa_data, addrlen);
		
		lomac_plm_lookup_name((const char *)name, &lattr);
		
		lobj.lo_type = LO_TYPE_INODE;
		lobj.lo_object.inode = SOCK_INODE(sock);
		set_object_lattr(&lobj, lattr);
	} else {
		lobj.lo_type = LO_TYPE_INODE;
		lobj.lo_object.inode = SOCK_INODE(sock);
	}

	return 0;
}

static int lomac_socket_listen (struct socket *sock, int backlog)
{
//	PDEBUG("lomac_socket_listen\n");
	return 0;
}

static int lomac_socket_accept (struct socket *sock, struct socket *newsock)
{
//	PDEBUG("lomac_socket_accept\n");
	return 0;
}

static void lomac_socket_post_accept (struct socket *sock, 
				      struct socket *newsock)
{
	lattr_t lattr;
	int err;
	lomac_object_t lobj;
	
	struct inode *s_inode = SOCK_INODE(sock);
	struct inode *new_s_inode = SOCK_INODE(newsock);

//	PDEBUG("lomac_socket_post_accept\n");

	if(s_inode->i_security == NULL)
	  PDEBUG("No socket inode security\n");
	if(new_s_inode->i_security == NULL)
	  PDEBUG("No new socket inode security\n");

	if (new_s_inode->i_security == NULL) {
		err = inode_alloc_security(new_s_inode);
		if (err) {
			PDEBUG("lomac_socket_post_accept: alloc security error\n");
			return;
		}
	}

	lobj.lo_type = LO_TYPE_INODE;
	lobj.lo_object.inode = s_inode;
	get_object_lattr(&lobj, &lattr);

	lobj.lo_type = LO_TYPE_INODE;
	lobj.lo_object.inode = new_s_inode;
	set_object_lattr(&lobj, lattr);

	return;
}

static int lomac_socket_sendmsg (struct socket *sock, struct msghdr *msg,
				 int size)
{
  //	PDEBUG("lomac_socket_sendmsg\n");

	struct inode *ino = SOCK_INODE(sock);

	if(current->security == NULL)
	  return 0; //before the module initiated
	if (sock->sk->sk_pair == NULL
	    || sock->sk->sk_peercred.pid != sock->sk->sk_pair->sk_peercred.pid
	    || sock->sk->sk_peercred.uid != sock->sk->sk_pair->sk_peercred.uid
	    || sock->sk->sk_peercred.gid != sock->sk->sk_pair->sk_peercred.gid
	    || sock->sk->sk_pair->sk_socket == NULL
	    || sock->sk != sock->sk->sk_pair->sk_socket->sk) {

		lomac_object_t lobj;
		lattr_t lattr;
		int err;

		lobj.lo_type = LO_TYPE_INODE;
		lobj.lo_object.inode = ino;

		if(ino->i_security==NULL){
			err = inode_alloc_security(ino);
			if (err) {
				printk("lomac_socket_sendmsg: alloc security error\n");
				return 0;
			}
			lattr.level = LOMAC_LOWEST_LEVEL;
			lattr.flags = 0;
			set_object_lattr(&lobj, lattr);
		}
		if (!mediate_subject_object("send", current, &lobj)) {
			return -EPERM;
		}
	} else {
		/*
		 * This is a send to a socket in a socketpair() pair.
		 * Mark both sockets in pair with the appropriate level.
		 */
		lomac_object_t lobj1, lobj2;
		lattr_t lattr;
		int err;
		
		struct inode *pair_ino = SOCK_INODE(sock->sk->sk_pair->sk_socket);

		lobj1.lo_type = LO_TYPE_SOCKETPAIR;
		lobj1.lo_object.socket = sock;
		if(ino->i_security == NULL){
			err = inode_alloc_security(ino);
			if (err) 
			{
				printk("lomac_socket_sendmsg: alloc security error\n");
				return 0;
			}
			lattr.level = LOMAC_LOWEST_LEVEL;
			lattr.flags = 0;
			set_object_lattr(&lobj1, lattr);
		}
		if (monitor_pipe_write(current, &lobj1) !=0)
			return -EPERM;
		lobj2.lo_type = LO_TYPE_SOCKETPAIR;
		lobj2.lo_object.socket = sock->sk->sk_pair->sk_socket;
		if(pair_ino->i_security == NULL){
			err = inode_alloc_security(pair_ino);
			if (err) {
				PDEBUG("lomac_socket_sendmsg: alloc security error\n");
				return 0;
			}
		}
		get_object_lattr(&lobj1, &lattr);
		set_object_lattr(&lobj2, lattr);
	}

	return 0;
}

static int lomac_socket_recvmsg (struct socket *sock, struct msghdr *msg,
				 int size, int flags)
{
  //        PDEBUG("lomac_socket_recvmsg\n");

	struct inode *ino = SOCK_INODE(sock);

	if(current->security == NULL)
	  return 0; //before the module initiated
	if (sock->sk->sk_pair == NULL
	    || sock->sk->sk_peercred.pid != sock->sk->sk_pair->sk_peercred.pid
	    || sock->sk->sk_peercred.uid != sock->sk->sk_pair->sk_peercred.uid
	    || sock->sk->sk_peercred.gid != sock->sk->sk_pair->sk_peercred.gid
	    || sock->sk->sk_pair->sk_socket == NULL
	    || sock->sk != sock->sk->sk_pair->sk_socket->sk) {

		lomac_object_t lobj;
		lattr_t lattr;
		int err;

		lobj.lo_type = LO_TYPE_INODE;
		lobj.lo_object.inode = ino;

		if(ino->i_security==NULL){
			err = inode_alloc_security(ino);
			if (err) {
				PDEBUG("lomac_socket_recvmsg: alloc security error\n");
				return 0;
			}
			lattr.level = LOMAC_LOWEST_LEVEL;
			lattr.flags = 0;
			set_object_lattr(&lobj, lattr);
		}

		if(monitor_read_object(current, &lobj)!=0)
			return -EPERM;
	} else {
		/*
		 * This is a receive from a socket in a pair created by
		 * socketpair().  Monitor it as we would a pipe read,
		 * except for allowing for arbitrary numbers of sleeps.
		 */
 
		lomac_object_t lobj1, lobj2;
		lattr_t lattr;
		int err;
		
		struct inode *pair_ino = SOCK_INODE(sock->sk->sk_pair->sk_socket);

		lobj1.lo_type = LO_TYPE_SOCKETPAIR;
		lobj1.lo_object.socket = sock;
		if(ino == NULL){
			err = inode_alloc_security(ino);
			if (err) {
				PDEBUG("lomac_socket_recvmsg: alloc security error\n");
				return 0;
			}
			lattr.level = LOMAC_LOWEST_LEVEL;
			lattr.flags = 0;
			set_object_lattr(&lobj1, lattr);
		}
		if (monitor_read_net_socket(current) !=0)
			return -EPERM;
		lobj2.lo_type = LO_TYPE_SOCKETPAIR;
		lobj2.lo_object.socket = sock->sk->sk_pair->sk_socket;

//		sock->sk->pair is not NULL;
//		sock->sk->pair->socket is NULL;
//		Thus, cannot get to inode!;
			
		if(pair_ino->i_security == NULL){
			err = inode_alloc_security(pair_ino);
			if (err) {
				PDEBUG("lomac_socket_recvmsg: alloc security error\n");
				return 0;
			}
		}
		get_object_lattr(&lobj1, &lattr);
		set_object_lattr(&lobj2, lattr);
	}

	return 0;
}

static int lomac_socket_getsockname (struct socket *sock)
{
//	PDEBUG("lomac_socket_getsockname\n");
	return 0;
}

static int lomac_socket_getpeername (struct socket *sock)
{
//	PDEBUG("lomac_socket_getpeername\n");
	return 0;
}

static int lomac_socket_setsockopt (struct socket *sock, int level, int optname)
{
//	PDEBUG("lomac_socket_setsockopt\n");
	return 0;
}

static int lomac_socket_getsockopt (struct socket *sock, int level, int optname)
{
//	PDEBUG("lomac_socket_getsockopt\n");
	return 0;
}

static int lomac_socket_shutdown (struct socket *sock, int how)
{
//	PDEBUG("lomac_socket_shutdown\n");
	return 0;
}

static int lomac_socket_sock_rcv_skb (struct sock *sk, struct sk_buff *skb)
{
	return 0;
}

static inline int lomac_sk_alloc_security (struct sock *sk, int family, int priority)
{
	return 0;
}

static inline void lomac_sk_free_security (struct sock *sk)
{
}
#endif	/* CONFIG_SECURITY_NETWORK */

static void lomac_d_instantiate (struct dentry *dentry, struct inode *inode)
{
	lomac_object_t lobj;
	struct lomac_node * ln;
	int err;
	char *name;
	lattr_t obj_lattr;
	char buf[LOMAC_MAX_PATH_LEN];

	if(!dentry)
	  printk("no dentry in d_instantiate\n");
	if (dentry->d_inode == NULL) {
		return;
	}

	if(dentry->d_inode->i_security != NULL){
	  lobj.lo_type = LO_TYPE_INODE;
	  lobj.lo_object.inode = dentry->d_inode;

	  get_object_lattr(&lobj, &obj_lattr);

	  if(IS_VALID_LEVEL(obj_lattr.level)){
	    return;
	  }
	}

	if(current->security == NULL)
	  printk("lomac_inode_lookup: no task security\n");

	if (dentry->d_inode->i_security == NULL) {
		err = inode_alloc_security(dentry->d_inode);
		if (err) 
		{
			PDEBUG("lomac_inode_lookup: alloc security error\n");
			return;
		}
	}

	if(!special_file(inode->i_mode)){

	ln = (struct lomac_node *)inode->i_security;

	if(ln->ln_vp == NULL
		        && ln->ln_lowervp == NULL
		        && ln->ln_underpolicy == NULL
	   && ln->ln_entry == NULL){
	  get_dentry_lattr(dentry, &obj_lattr);
	  lobj.lo_type = LO_TYPE_INODE;
	  lobj.lo_object.inode = dentry->d_inode;

	  set_object_lattr(&lobj, obj_lattr);
	  return;
	}
	lomac_plm_init_lomacfs_inode(inode,
				     dentry->d_inode,
				     &dentry->d_name,
				     current->security);
	
	lobj.lo_type = LO_TYPE_INODE;
	lobj.lo_object.inode = dentry->d_inode;

	}

	else{
	  if(dentry->d_sb->s_magic == PIPEFS_MAGIC)
	    lomac_initialize_pipe(dentry->d_inode);
	  else if(dentry->d_inode->i_sock)
	    lomac_initialize_socket(dentry->d_inode);
	  else{
	  name = get_dentry_pathname(dentry, buf, LOMAC_MAX_PATH_LEN);
	  if(name != NULL){
	    lomac_plm_lookup_name(name, &obj_lattr);

	    lobj.lo_type = LO_TYPE_INODE;
	    lobj.lo_object.inode = dentry->d_inode;

	    if(dentry->d_inode == NULL)
	      printk("inode NULL\n");
	    if(dentry->d_inode->i_security == NULL)
	      printk("inode security not allocated\n");
	    set_object_lattr(&lobj, obj_lattr);
	  }else{
	    printk("dentry has no pathname\n");
	  }
	  }

	}

	return;
}

static int lomac_getprocattr(struct task_struct *p, char *name, void *value, size_t size)
{
  lattr_t *task_sec;

  if(!size)
    return -ERANGE;

  if(!strcmp(name, "current")){
    task_sec = (lattr_t *)p->security;

    if(task_sec == NULL) {
      return -EFAULT;
    }

    size = sizeof(lattr_t);

    memcpy(value, task_sec, size);
  }
  else
 	return -EINVAL;

  return size;

}

static int lomac_setprocattr(struct task_struct *p, char *name, void *value, size_t size)
{
  if (current != p)
    return -EACCES;

  if(!size)
    return -ERANGE;

  if(!strcmp(name, "exec"))
    lomac_make_proc_low(value);
  else if(!strcmp(name, "fscreate"))
    lomac_set_proc_level(value);
  else
 	return -EINVAL;

	return size;
}

struct security_operations lomac_security_ops = {
	ptrace:				lomac_ptrace,
	capget:				lomac_capget,
	capset_check:			lomac_capset_check,
	capset_set:			lomac_capset_set,
	acct:				lomac_acct,
	sysctl:				lomac_sysctl,
	capable:			lomac_capable,
	quotactl:			lomac_quotactl,
	quota_on:			lomac_quota_on,
	syslog:				lomac_syslog,
       	vm_enough_memory:               lomac_vm_enough_memory,

	netlink_send:			lomac_netlink_send,
	netlink_recv:			lomac_netlink_recv,
	
	bprm_alloc_security:		lomac_binprm_alloc_security,
	bprm_free_security:		lomac_binprm_free_security,
	bprm_apply_creds:		lomac_binprm_apply_creds,
	bprm_set_security:		lomac_binprm_set_security,
	bprm_check_security:		lomac_binprm_check_security,

	sb_alloc_security:		lomac_sb_alloc_security,
	sb_free_security:		lomac_sb_free_security,
	sb_kern_mount:                  lomac_sb_kern_mount,
	sb_statfs:			lomac_sb_statfs,
	sb_mount:			lomac_sb_mount,
	sb_copy_data:                   lomac_sb_copy_data,
	sb_check_sb:			lomac_sb_check_sb,
	sb_umount:			lomac_sb_umount,
	sb_umount_close:		lomac_sb_umount_close,
	sb_umount_busy:			lomac_sb_umount_busy,
	sb_post_remount:		lomac_sb_post_remount,
	sb_post_mountroot:		lomac_sb_post_mountroot,
	sb_post_addmount:		lomac_sb_post_addmount,
	sb_pivotroot:			lomac_sb_pivotroot,
	sb_post_pivotroot:		lomac_sb_post_pivotroot,
	
	inode_alloc_security:		lomac_inode_alloc_security,
	inode_free_security:		lomac_inode_free_security,
	inode_create:			lomac_inode_create,
	inode_post_create:		lomac_inode_post_create,
	inode_link:			lomac_inode_link,
	inode_post_link:		lomac_inode_post_link,
	inode_unlink:			lomac_inode_unlink,
	inode_symlink:			lomac_inode_symlink,
	inode_post_symlink:		lomac_inode_post_symlink,
	inode_mkdir:			lomac_inode_mkdir,
	inode_post_mkdir:		lomac_inode_post_mkdir,
	inode_rmdir:			lomac_inode_rmdir,
	inode_mknod:			lomac_inode_mknod,
	inode_post_mknod:		lomac_inode_post_mknod,
	inode_rename:			lomac_inode_rename,
	inode_post_rename:		lomac_inode_post_rename,
	inode_readlink:			lomac_inode_readlink,
	inode_follow_link:		lomac_inode_follow_link,
	inode_permission:		lomac_inode_permission,
	inode_setattr:			lomac_inode_setattr,
	inode_getattr:                  lomac_inode_getattr,
	inode_delete:                   lomac_inode_delete,
	inode_setxattr:                 lomac_inode_setxattr,
	inode_post_setxattr:            lomac_inode_post_setxattr,
	inode_getxattr:                 lomac_inode_getxattr,
	inode_removexattr:              lomac_inode_removexattr,
	inode_getsecurity:              lomac_inode_getsecurity,
	inode_setsecurity:              lomac_inode_setsecurity,
	inode_listsecurity:             lomac_inode_listsecurity,

	file_permission:		lomac_file_permission,
	file_alloc_security:		lomac_file_alloc_security,
	file_free_security:		lomac_file_free_security,
	file_ioctl:			lomac_file_ioctl,
	file_mmap:			lomac_file_mmap,
	file_mprotect:			lomac_file_mprotect,
	file_lock:			lomac_file_lock,
	file_fcntl:			lomac_file_fcntl,
	file_set_fowner:		lomac_file_set_fowner,
	file_send_sigiotask:		lomac_file_send_sigiotask,
	file_receive:			lomac_file_receive,

	task_create:			lomac_task_create,
	task_alloc_security:		lomac_task_alloc_security,
	task_free_security:		lomac_task_free_security,
	task_setuid:			lomac_task_setuid,
	task_post_setuid:		lomac_task_post_setuid,
	task_setgid:			lomac_task_setgid,
	task_setpgid:			lomac_task_setpgid,
	task_getpgid:			lomac_task_getpgid,
	task_getsid:			lomac_task_getsid,
	task_setgroups:			lomac_task_setgroups,
	task_setnice:			lomac_task_setnice,
	task_setrlimit:			lomac_task_setrlimit,
	task_setscheduler:		lomac_task_setscheduler,
	task_getscheduler:		lomac_task_getscheduler,
	task_wait:			lomac_task_wait,
	task_kill:			lomac_task_kill,
	task_prctl:			lomac_task_prctl,
	task_reparent_to_init:		lomac_task_reparent_to_init,
	task_to_inode:                  lomac_task_to_inode,

	d_instantiate:                  lomac_d_instantiate,
	setprocattr:                    lomac_setprocattr,
	getprocattr:                    lomac_getprocattr,

	ipc_permission:			lomac_ipc_permission,
	
	msg_msg_alloc_security:		lomac_msg_msg_alloc_security,
	msg_msg_free_security:		lomac_msg_msg_free_security,
	
	msg_queue_alloc_security:	lomac_msg_queue_alloc_security,
	msg_queue_free_security:    	lomac_msg_queue_free_security,
	msg_queue_associate:		lomac_msg_queue_associate,
	msg_queue_msgctl:		lomac_msg_queue_msgctl,
	msg_queue_msgsnd:		lomac_msg_queue_msgsnd,
	msg_queue_msgrcv:		lomac_msg_queue_msgrcv,
	
	shm_alloc_security:		lomac_shm_alloc_security,
	shm_free_security:		lomac_shm_free_security,
	shm_associate:			lomac_shm_associate,
	shm_shmctl:			lomac_shm_shmctl,
	shm_shmat:			lomac_shm_shmat,
	
	sem_alloc_security:		lomac_sem_alloc_security,
	sem_free_security:		lomac_sem_free_security,
	sem_associate:			lomac_sem_associate,
	sem_semctl:			lomac_sem_semctl,
	sem_semop:			lomac_sem_semop,
	
	register_security:		lomac_register_security,
	unregister_security:		lomac_unregister_security,

#ifdef CONFIG_SECURITY_NETWORK
	unix_stream_connect:    	lomac_unix_stream_connect,
	unix_may_send:			lomac_unix_may_send,

	socket_create:			lomac_socket_create,
	socket_post_create:		lomac_socket_post_create,
	socket_bind:			lomac_socket_bind,
	socket_connect:			lomac_socket_connect,
	socket_listen:			lomac_socket_listen,
	socket_accept:			lomac_socket_accept,
	socket_post_accept:		lomac_socket_post_accept,
	socket_sendmsg:			lomac_socket_sendmsg,
	socket_recvmsg:			lomac_socket_recvmsg,
	socket_getsockname:		lomac_socket_getsockname,
	socket_getpeername:		lomac_socket_getpeername,
	socket_getsockopt:		lomac_socket_getsockopt,
	socket_setsockopt:		lomac_socket_setsockopt,
	socket_shutdown:		lomac_socket_shutdown,
	socket_sock_rcv_skb:		lomac_socket_sock_rcv_skb,
#endif
};

#if defined(CONFIG_SECURITY_lomac_MODULE)
#define MY_NAME THIS_MODULE->name
#else
#define MY_NAME "lomac"
#endif

static int __init lomac_init (void)
{
	struct vfsmount *root_mnt;
	struct super_block *root_sb;
	struct lomac_node *root_ino_sec;
	int error;
	struct list_head *head;
	struct list_head * tmp;
	struct inode *inode;
	lomac_object_t lobj;
	lattr_t lattr;

	/* register ourselves with the security framework */
	if (register_security (&lomac_security_ops)) {
		printk (KERN_INFO 
			"Failure registering lomac module with the kernel\n");
		/* try registering with primary module */
		if (mod_reg_security (MY_NAME, &lomac_security_ops)) {
			printk (KERN_INFO "Failure registering lomac module "
				"with primary security module.\n");
			return -EINVAL;
		}
	}

	/* Load in the policy */
       	if ((error = lomac_plm_initialize())) {
		/* Initialize error */
		unlock_kernel();
		lomac_exit();

		return error;
	}
	printk("policy loaded\n");

	// Set up the security stuff for the already running processes
	lock_kernel();
	spin_lock(&dcache_lock);
 
	if ((error = lomac_initialize_procs())) {
		/* Proc initialize error */
		unlock_kernel();
		lomac_exit();

		return error;
	}
	printk("running processes set up\n");

	/* Initialize all the cached dentry's inodes */
	root_mnt = current->fs->rootmnt;
	root_sb = root_mnt->mnt_sb;

	error = lomac_inode_alloc_security(root_mnt->mnt_root->d_inode);
	if (error) {
		/* Memory allocate error */
		unlock_kernel();
		lomac_exit();

		return error;
	}
	printk("alloc security finished\n");
	root_ino_sec = (struct lomac_node *)
		root_mnt->mnt_root->d_inode->i_security;

	lomac_plm_init_root(root_ino_sec);
	printk("root initiated\n");
	lomac_initialize_sb(root_mnt->mnt_sb, "", 0);
	printk("sb initiated\n");
	lomac_initialize_inodes(root_mnt, root_sb->s_root, root_mnt);
	printk("root node set up\n");

	// Look through all inodes and fix up the ones that
	// were missed by lomac_initialize_inodes() -- they probably didn't
	// have a "real" name to look up
	tmp = head = &root_mnt->mnt_root->d_inode->i_list;
	while ((tmp = tmp->prev) != head) {
		inode = list_entry(tmp, struct inode, i_list);
		if (inode->i_security == NULL) {
			if (inode->i_pipe) {
				error = lomac_initialize_pipe(inode);
				if (error) {
					return error;
				}
			}
			else if (inode->i_sock) {
				error = lomac_initialize_socket(inode);
				if (error) {
					return error;
				}
			} else {
				error = inode_alloc_security(inode);
				if (error) {
					PDEBUG("lomac init: alloc security error\n");
					return error;
				}
				lobj.lo_type = LO_TYPE_INODE;
				lobj.lo_object.inode = inode;

				lattr.level = LOMAC_HIGHEST_LEVEL;
				lattr.flags = LOMAC_HIGHEST_LEVEL;
				set_object_lattr(&lobj, lattr);
			}
			
		}
	}

	printk("module initialized\n");
	spin_unlock(&dcache_lock);
	unlock_kernel();
#ifdef LOMACFS1
	spin_lock_init(&mount_lock);

	PDEBUG("registering filesystem\n");
	error = register_filesystem(&lomacfs_fs_type);
	if (error) {
		PDEBUG("register_filesystem failed with %d\n", error);
		return error;
	}
#endif	//LOMACFS1

	printk(KERN_INFO "LOMAC initialized\n");
	return 0;
}

static void __exit lomac_exit (void)
{
#ifdef LOMACFS1
	/* remove the lomacfs file system */
	unregister_filesystem(&lomacfs_fs_type);
#endif	//LOMACFS1

	/* remove ourselves from the security framework */
	if (secondary) {
		if (mod_unreg_security (MY_NAME, &lomac_security_ops)) {
			printk (KERN_INFO "Failure unregistering lomac module "
                    "with primary module.\n");
        }
        
		return;
	}
 
	if (unregister_security (&lomac_security_ops)) {
		printk (KERN_INFO
			"Failure unregistering lomac module with the kernel\n");
	}

    lomac_plm_uninitialize();
}

module_init (lomac_init);
module_exit (lomac_exit);

MODULE_DESCRIPTION("PINTL implementation of MEI MAC");
MODULE_LICENSE("GPL");


#define VALID_LEVEL(l) (l <= LOMAC_HIGHEST_LEVEL && l >= LOMAC_LOWEST_LEVEL)

