LOMAC LSM is a Linux Security Module (LSM) based on the original LOMAC.  It 
implements a simple form of Mandatory Access Control mechanism based on Biba's 
Low Water-Mark Access Control model.

To use LOMAC LSM, simply do the following.

1. change the KDIR in Makefile to whichever kernel sourcedirectory is 
   appropriate.
2. make
3. install the module use insmod
