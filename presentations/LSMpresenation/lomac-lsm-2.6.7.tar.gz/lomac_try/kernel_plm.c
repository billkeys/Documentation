/*-
 * Copyright (c) 2005 Panasonic Corporation of North America
 *
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *

 * Copyright (c) 2001 Networks Associates Technology, Inc.
 * All rights reserved.
 *
 * This software was developed for the FreeBSD Project by NAI Labs, the
 * Security Research Division of Network Associates, Inc. under
 * DARPA/SPAWAR contract N66001-01-C-8035 ("CBOSS"), as part of the DARPA
 * CHATS research program.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * $Id$
 * $FreeBSD: src/sys/security/lomac/kernel_plm.c,v 1.2 2002/03/13 22:55:20 rwatson Exp $
 */

#include <linux/list.h>
#include <linux/slab.h>
#include <linux/fs.h>

#include "lomac.h"
#include "lomacfs.h"
#include "policy_plm.h"
#include "kernel_util.h"
#include "kernel_interface.h"


char *strsep(register char **stringp, register const char *delim);

int
lomac_plm_lookup_name(const char *name,
		      lattr_t *lattr);

static struct lomac_node_entry *
lomac_plm_subtree_find_cnp(struct lomac_node_entry *root,
                           const unsigned char *nameptr,
			   unsigned int namelen);
static int
lomac_plm_search_fullpath(char *path,
                          struct lomac_node_entry **plne,
                          struct lomac_node_entry **lne);

/*
 * Get next token from string *stringp, where tokens are possibly-empty
 * strings separated by characters from delim.
 *
 * Writes NULs into the string at *stringp to end tokens.
 * delim need not remain constant from call to call.
 * On return, *stringp points past the last NUL written (if there might
 * be further tokens), or is NULL (if there are definitely no more tokens).
 *
 * If *stringp is NULL, strsep returns NULL.
 */
char *
strsep(stringp, delim)
	register char **stringp;
	register const char *delim;
{
	register char *s;
	register const char *spanp;
	register int c, sc;
	char *tok;

	if ((s = *stringp) == NULL)
		return (NULL);
	for (tok = s;;) {
		c = *s++;
		spanp = delim;
		do {
			if ((sc = *spanp++) == c) {
				if (c == 0)
					s = NULL;
				else
					s[-1] = 0;
				*stringp = s;
				return (tok);
			}
		} while (sc != 0);
	}
	/* NOTREACHED */
}

struct lomac_node_entry lomac_node_entry_root = {
	{ NULL, NULL },
	{ NULL, NULL },
	LN_HIGHEST_LEVEL | LN_INHERIT_HIGH,
	"/"
};


/*
 * New function -- searches through lomac policy tree for full path file name
 *
 */
static int
lomac_plm_search_fullpath(char *path,
                          struct lomac_node_entry **plne,
                          struct lomac_node_entry **lne)
{
	char *comp;
	int depth;

	*plne = *lne = &lomac_node_entry_root;
	depth = 0;
	for (;; depth++) {
		comp = strsep(&path, "/");
		if (comp == NULL)
			break;
		if (depth == 0) {	/* special case: beginning / */
			if (*comp == '\0')
				continue;
			else {
				printk("lomac_plm: not absolute path "
				       "\"%s\"\n", path);
				KERNEL_ASSERT("not absolute path", 0 == 1); //xxxxxxx
				return -EINVAL;
			}
		} else if (depth == 1) {	/* special case: "/" */
			if (*comp == '\0' && strsep(&path, "/") == NULL)
				break;
		}
		if (*comp == '\0' ||
		    strcmp(comp, ".") == 0 ||
		    strcmp(comp, "..") == 0) {
			printk("lomac_plm: empty path component in "
			       "\"%s\"\n", path);
			return -EINVAL;
		}
		*plne = *lne;
		*lne = lomac_plm_subtree_find_cnp(*plne,
						  (const unsigned char *)comp,
						  (unsigned int)strlen(comp));
		if (*lne == NULL) {
			break;
		}
	}
    
	return 0;
}


/*
 * Changed from lomac_plm_subtree_find_cnp()
 *   Instead of passing in a componentname *, it's now a char *
 *
 * It searches through the children of a lomac_node_entry
 *
 */
static struct lomac_node_entry *
lomac_plm_subtree_find_cnp(struct lomac_node_entry * root,
                           const unsigned char * nameptr,
			   unsigned int len) {
	struct lomac_node_entry *lne = NULL;
	struct list_head *p;

	list_for_each(p, &root->ln_children) {
		lne = list_entry(p, struct lomac_node_entry, ln_chain);
		if (strlen(lne->ln_name) == len &&
		    memcmp(lne->ln_name, nameptr, len) == 0) {
			break;
		}
	}

	return (p != &root->ln_children ? lne : NULL);
}

int
lomac_plm_lookup_inode_and_name(struct inode *inode,
				const unsigned char * name,
				unsigned int len,
				lattr_t * lattr) 
{
	lomac_object_t lobj;
	char *buf;
	char *ptr;

	buf = kmalloc(LOMAC_MAX_PATH_LEN, GFP_KERNEL);
	if (buf == NULL) {
		return -ENOMEM;
	}

	if (name[0] == '/') {
		memcpy(buf, name, len);
		buf[len + 1] = '\0';
		
		lomac_plm_lookup_name((const char *)buf, lattr);
	} else {
		if (inode != NULL) {
			ptr = get_inode_pathname(inode, buf, LOMAC_MAX_PATH_LEN);
		} else {
			ptr = get_dentry_pathname(current->fs->pwd, 
						  buf,
						  LOMAC_MAX_PATH_LEN);
		}
		if (ptr != NULL) {
			memmove(buf, ptr, strlen(ptr) + 1);
	
			ptr = buf + strlen(buf);
			strcat(ptr, "/");

			// Full path
			memcpy(ptr + 1, name, len);
			ptr[len + 1] = '\0';
			
			lomac_plm_lookup_name((const char *)buf, lattr);
		} else {
			lobj.lo_type = LO_TYPE_INODE;
			lobj.lo_object.inode = inode;
			get_object_lattr(&lobj, lattr);
		}
	}

	kfree(buf);

	return 0;
}

int
lomac_plm_lookup_inode(char *name, struct inode *ino)
{
	struct lomac_node *ln = ino->i_security;
	struct lomac_node_entry *lne = NULL;
	struct lomac_node_entry *plne = NULL;
	int err;

	err = lomac_plm_search_fullpath(name, &plne, &lne);
	if (err) {
		return err;
	}
    
	if (lne == NULL) {
		// Full path not matched -- use parent (plne)
		ln->ln_flags = plne->ln_flags & LN_INHERIT_MASK;
		ln->ln_underpolicy = plne;
		ln->ln_entry = NULL;
        
		switch (ln->ln_flags) {
		case LN_INHERIT_LOW:
			ln->ln_flags |= LN_LOWEST_LEVEL;
			break;
		case LN_INHERIT_SUBJ:
			ln->ln_flags |= LN_SUBJ_LEVEL;
			break;
		case LN_INHERIT_HIGH:
			ln->ln_flags |= LN_HIGHEST_LEVEL;
			break;
		}
		/*
		 * Get child attributes as regular attributes.  The regular
		 * attributes have been cleared.  Regular attributes are only
		 * used if there is a "perfect" match.
		 */
		ln->ln_flags |= (plne->ln_flags & LN_CHILD_ATTR_MASK)
			>> LN_CHILD_ATTR_SHIFT;
	}
	else {
		// Full path matched, use lne
		ln->ln_flags = lne->ln_flags;
		ln->ln_underpolicy = lne;
		ln->ln_entry = lne;
	}

	return 0;
}


int
lomac_plm_lookup_name(const char *name,
		      lattr_t *lattr)
{
	struct lomac_node_entry *lne = NULL;
	struct lomac_node_entry *plne = NULL;
	int err;
    
	err = lomac_plm_search_fullpath((char *)name, &plne, &lne);
	if (err) {
		lattr = NULL;
		return err;
	}
    
	if (lne == NULL) {
		// Full path not matched -- use parent (plne)
		switch (plne->ln_flags & LN_INHERIT_MASK) {
		case LN_INHERIT_LOW:
			lattr->level = LOMAC_LOWEST_LEVEL;
			break;
		case LN_INHERIT_SUBJ:
			lattr->level = LOMAC_SUBJ_LEVEL;
			break;
		case LN_INHERIT_HIGH:
			lattr->level = LOMAC_HIGHEST_LEVEL;
			break;
		}
		/*
		 * Get child attributes as regular attributes.  The regular
		 * attributes have been cleared.  Regular attributes are only
		 * used if there is a "perfect" match.
		 */
		lattr->flags = (plne->ln_flags & LN_CHILD_ATTR_MASK)
			>> LN_CHILD_ATTR_SHIFT;
	} else {
		// Full path matched, use lne
		switch (lne->ln_flags & LN_LEVEL_MASK) {
		case LN_LOWEST_LEVEL:
			lattr->level = LOMAC_LOWEST_LEVEL;
			break;
		case LN_SUBJ_LEVEL:
			lattr->level = LOMAC_SUBJ_LEVEL;
			break;
		case LN_HIGHEST_LEVEL:
			lattr->level = LOMAC_HIGHEST_LEVEL;
			break;
		default:
			KERNEL_ASSERT("This shouldn't happen", 1 == 0);
			break;
		}
		
		lattr->flags = lne->ln_flags & LN_ATTR_MASK;
	}

	return 0;
}
	
	
void lomac_plm_init_root(struct lomac_node * root_ino_sec)
{
	root_ino_sec->ln_vp = NULL;
	root_ino_sec->ln_lowervp = NULL;
	root_ino_sec->ln_flags = lomac_node_entry_root.ln_flags;
	root_ino_sec->ln_underpolicy = &lomac_node_entry_root;
	root_ino_sec->ln_entry = &lomac_node_entry_root;

	return;
}


/*
 * Adapted from lomac_plm_init_lomacfs_vnode()
 *    vnode changed to inode
 * dvp is parent directory inode
 * vp is inode in question
 * name is full path
 * subjlattr is lomac attributes of subject accessing inode
 * ln is lomac_node set with fields from policy tree
 */
void
lomac_plm_init_lomacfs_inode(struct inode *dvp,
			     struct inode *vp,
			     struct qstr *cnp,		     
			     lattr_t *subjlattr)
{
	struct lomac_node *ln = vp->i_security;
	struct lomac_node_entry *mlne = NULL;

 	/*
	 * Only "/" has no parent, so inherit directly from our PLM root.
	 */
	if (dvp == NULL) {
		ln->ln_flags = lomac_node_entry_root.ln_flags;
		ln->ln_entry = ln->ln_underpolicy = &lomac_node_entry_root;
	} else {
		struct lomac_node *dln = dvp->i_security;
		struct lomac_node_entry *dlne = dln->ln_entry;
		int fixup_inherit = 0;

		/*
		 * If we have no directory-specific entry, we inherit
		 * directly from the lomac_node's previously-inherited
		 * flags implicitly, otherwise we inherit explicitly
		 * from the corresponding lomac_node_entry.
		 */
		if (dlne == NULL) {
			ln->ln_flags = dln->ln_flags & LN_INHERIT_MASK;
			fixup_inherit = 1;
			ln->ln_underpolicy = dln->ln_underpolicy;
			ln->ln_entry = NULL;
		} else if ((mlne = lomac_plm_subtree_find_cnp(dlne,
							      cnp->name,
							      cnp->len)) ==
		    NULL) {
			ln->ln_flags = dlne->ln_flags & LN_INHERIT_MASK;
			fixup_inherit = 2;
			ln->ln_underpolicy = dlne;
			ln->ln_entry = NULL;
		} else {
			ln->ln_entry = ln->ln_underpolicy = mlne;
		}
		if (fixup_inherit) {
			switch (ln->ln_flags) {
			case LN_INHERIT_LOW:
				ln->ln_flags |= LN_LOWEST_LEVEL;
				break;
			case LN_INHERIT_SUBJ:
				if (subjlattr->level == LOMAC_HIGHEST_LEVEL)
					ln->ln_flags |= LN_HIGHEST_LEVEL;
				else {
					ln->ln_flags &= ~LN_INHERIT_MASK;
					ln->ln_flags |= LN_INHERIT_LOW |
					    LN_LOWEST_LEVEL;
				}
				break;
			case LN_INHERIT_HIGH:
				ln->ln_flags |= LN_HIGHEST_LEVEL;
				break;
			}
			if (fixup_inherit == 2) {
				ln->ln_flags |=
				    (dlne->ln_flags & LN_CHILD_ATTR_MASK) >>
					LN_CHILD_ATTR_SHIFT;
			} else {
				ln->ln_flags |=
				    (dln->ln_underpolicy->ln_flags & LN_CHILD_ATTR_MASK) >>
					LN_CHILD_ATTR_SHIFT;
			}
		} else {
			/* this is the only case where mlne != NULL */
			ln->ln_flags &= ~(LN_INHERIT_MASK | LN_ATTR_MASK);
			ln->ln_flags |= mlne->ln_flags &
				(LN_INHERIT_MASK | LN_ATTR_MASK);
			ln->ln_flags |= mlne->ln_flags & LN_LEVEL_MASK;
		}
	}

	//	KERNEL_ASSERT("lomac_node has no level", ln->ln_flags & LN_LEVEL_MASK);
	//	KERNEL_ASSERT("lomac_node has no inherit",
	//		      ln->ln_flags & LN_INHERIT_MASK);
#ifdef INVARIANTS
	if (mlne != NULL) {
		KERNEL_ASSERT("lomac_node_entry has no level",
			      mlne->ln_flags & LN_LEVEL_MASK);
		KERNEL_ASSERT ("lomac_node_entry has no inherit",
			       mlne->ln_flags & LN_INHERIT_MASK);
	}
#endif /* INVARIANTS */

	return;
}


/*
 * Adapted from lomac_plm_init_lomacfs_vnode()
 *    vnode changed to inode
 *    parameters changed from xxxxx to yyyyy
 * dvp is parent directory inode
 * vp is inode in question
 * name is full path
 * subjlattr is lomac attributes of subject accessing inode
 * lattr is lomac attributes set from policy tree
 */
void
lomac_plm_init_lomac_task(char *filename,
                          lattr_t *subjlattr,
                          lattr_t *lattr) {
	struct lomac_node_entry *lne = NULL;
	struct lomac_node_entry *plne = NULL;
    int err;
    
    err = lomac_plm_search_fullpath(filename, &plne, &lne);
    if (err) {
        lattr = NULL;
        return;
    }
    
    if (lne == NULL) {
        // Full path not matched -- use parent (plne)
        lattr->flags = plne->ln_flags & LN_INHERIT_MASK;
        
        switch (lattr->flags) {
        case LN_INHERIT_LOW:
            lattr->level = LOMAC_LOWEST_LEVEL;
            break;
        case LN_INHERIT_SUBJ:
            if (subjlattr->level == LOMAC_HIGHEST_LEVEL) {
                lattr->level = LOMAC_HIGHEST_LEVEL;
            }
            else {
                lattr->flags &= ~LN_INHERIT_MASK;
                lattr->flags |= LN_INHERIT_LOW;
                lattr->level = LOMAC_LOWEST_LEVEL;
            }
            break;
        case LN_INHERIT_HIGH:
            lattr->level = LOMAC_HIGHEST_LEVEL;
            break;
        }
        /*
         * Get child attributes as regular attributes.  The regular
         * attributes have been cleared
         */
        lattr->flags |=
            (plne->ln_flags & LN_CHILD_ATTR_MASK) >> LN_CHILD_ATTR_SHIFT;
    }
    else {
        // Full path matched, use lne
        lattr->flags = lne->ln_flags;

        lattr->flags &= ~(LN_INHERIT_MASK | LN_ATTR_MASK);
        lattr->flags |= lne->ln_flags & (LN_INHERIT_MASK | LN_ATTR_MASK);
        if ((lne->ln_flags & LN_LEVEL_MASK) == LN_SUBJ_LEVEL) {
            if (subjlattr->level == LOMAC_HIGHEST_LEVEL) {
                lattr->level = LN_HIGHEST_LEVEL;
            }
            else {
                lattr->level = LN_LOWEST_LEVEL;
            }
        }
        else {
            lattr->level = lne->ln_flags & LN_LEVEL_MASK;
        }
    }
    return;
}


static struct lomac_node_entry *
lomac_plm_subtree_find(struct lomac_node_entry *root, const char *name) {
	struct lomac_node_entry *lne = NULL;
	struct list_head *p;

    list_for_each(p, &root->ln_children) {
        lne = list_entry(p, struct lomac_node_entry, ln_chain);
		if (strcmp(name, lne->ln_name) == 0) {
			break;
        }
    }
    return (p != &root->ln_children ? lne : NULL);
}

static struct lomac_node_entry *
lomac_plm_subtree_new(struct lomac_node_entry *plne, char *name) {
	struct lomac_node_entry *lne;
    
    lne = kmalloc(sizeof(struct lomac_node_entry), GFP_KERNEL);
    if (!lne) {
        printk("kmalloc error\n");
        return NULL;
    }
    
    memset(lne, 0, sizeof(struct lomac_node_entry));

    INIT_LIST_HEAD(&lne->ln_children);
    INIT_LIST_HEAD(&lne->ln_chain);
    lne->ln_name = name;

	lne->ln_flags = plne->ln_flags & LN_INHERIT_MASK;
	switch (lne->ln_flags) {
	case LN_INHERIT_LOW:
		lne->ln_flags |= LN_LOWEST_LEVEL;
		break;
	case LN_INHERIT_HIGH:
		lne->ln_flags |= LN_HIGHEST_LEVEL;
		break;
	case LN_INHERIT_SUBJ:
		lne->ln_flags |= LN_SUBJ_LEVEL;
		break;
	default:
		// Error
		break;
	}

    list_add(&lne->ln_chain, &plne->ln_children);
    
	return (lne);
}

static void
lomac_plm_subtree_free(struct lomac_node_entry *lneself) {
	struct list_head *head = &lneself->ln_children;
	struct lomac_node_entry *lne;
    struct list_head *p;

    while (!list_empty(head)) {
        p = head->next;
        lne = list_entry(p, struct lomac_node_entry, ln_chain);
        list_del(&lne->ln_chain);
        lomac_plm_subtree_free(lne);
    }
	kfree(lneself);
}

struct string_list {
    struct list_head    entries;
	char                string[1];
};

// xxxxxxx This should be the same as the previous 1 line
//static struct list_head string_list_head = { &string_list_head,
//                                             &string_list_head };
static LIST_HEAD(string_list_head);

static char *
string_list_new(const char *s) {
	struct string_list *sl;

	sl = kmalloc(sizeof(*sl) + strlen(s), GFP_KERNEL);
    if (!sl) 
    {
        printk("kmalloc failed\n");
        return NULL;
    }
    
	strcpy(sl->string, s);
    list_add(&sl->entries, &string_list_head);
    
	return (sl->string);
}


void
lomac_plm_uninitialize(void) {
	struct list_head *head = &lomac_node_entry_root.ln_children;
	struct lomac_node_entry *lne;
	struct string_list *sl;
    struct list_head *p;

	while (!list_empty(head)) {
		p = head->next;
		lne = list_entry(p, struct lomac_node_entry, ln_chain);
		list_del(&lne->ln_chain);
		lomac_plm_subtree_free(lne);
	}

	while (!list_empty(&string_list_head)) {
		p = string_list_head.next;
		sl = list_entry(p, struct string_list, entries);
		list_del(&sl->entries);
		kfree(sl);
	}
}


int
lomac_plm_initialize(void) {
	struct lomac_node_entry *plne, *lne;
	plm_rule_t *pr;

    INIT_LIST_HEAD(&lomac_node_entry_root.ln_children);
    INIT_LIST_HEAD(&lomac_node_entry_root.ln_chain);
	for (pr = plm; pr->path != NULL; pr++) {
		char *path;
		char *comp;
		int depth;
		
		if (*pr->path == '\0') {
			printk("lomac_plm: invalid path \"%s\"\n", pr->path);
			return -EINVAL;
		}
		path = string_list_new(pr->path);
		if (!path) {
			return -ENOMEM;
		}

		lne = &lomac_node_entry_root;
		depth = 0;
		for (;; depth++) {
			plne = lne;
			comp = strsep(&path, "/");
			if (comp == NULL)
				break;
			if (depth == 0) {	/* special case: beginning / */
				if (*comp == '\0')
					continue;
				else {
					printk("lomac_plm: not absolute path "
					    "\"%s\"\n", pr->path);
					KERNEL_ASSERT("not absolute path", 0 == 1);       //xxxxxxx
					return -EINVAL;
				}
			} else if (depth == 1) {	/* special case: "/" */
				if (*comp == '\0' && strsep(&path, "/") == NULL)
					break;
			}
			if (*comp == '\0' ||
			    strcmp(comp, ".") == 0 ||
			    strcmp(comp, "..") == 0) {
				printk("lomac_plm: empty path component in "
				    "\"%s\"\n", pr->path);
				return -EINVAL;
			}
			lne = lomac_plm_subtree_find(plne, comp);
			if (lne == NULL) {
				lne = lomac_plm_subtree_new(plne, comp);
				lne->ln_path = plne->ln_path;
			}
		}
		lne->ln_path = pr->path;
        
		if (pr->flags == PLM_NOFLAGS)
			lne->ln_flags &= ~LN_LEVEL_MASK;
		else
			lne->ln_flags &= ~LN_INHERIT_MASK;
		lne->ln_flags |= 
		    plm_levelflags_to_node_flags[pr->level][pr->flags];
		if (pr->flags == PLM_NOFLAGS)
			lne->ln_flags |= pr->attr;
		else
			lne->ln_flags |= (pr->attr & LN_ATTR_MASK)
			    << LN_CHILD_ATTR_SHIFT;
	}

	return (0);
}



