/*-
 * Copyright (c) 2005 Panasonic Corporation of North America
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *
 * Copyright (c) 2001 Networks Associates Technology, Inc.
 * All rights reserved.
 *
 * This software was developed for the FreeBSD Project by NAI Labs, the
 * Security Research Division of Network Associates, Inc. under
 * DARPA/SPAWAR contract N66001-01-C-8035 ("CBOSS"), as part of the DARPA
 * CHATS research program.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * $Id$
 * $FreeBSD: src/sys/security/lomac/kernel_interface.h,v 1.2 2002/03/13 22:55:20 rwatson Exp $
 */

#ifndef KERNEL_INTERFACE_H
#define KERNEL_INTERFACE_H

#include <linux/sched.h>

#include "lomac.h"


typedef struct task_struct lomac_subject_t;

typedef struct lomac_object {
	enum lomac_object_type {
		LO_TYPE_INODE,		/* LOMAC vnode */
		LO_TYPE_VM_OBJECT,	/* VM object, not OBJT_VNODE */
		LO_TYPE_PIPE,		/* pipe */
		LO_TYPE_SOCKETPAIR      /* local-domain socket in socketpair */
	} lo_type;
	union {
		struct inode *inode;
		struct socket *socket;
	} lo_object;
} lomac_object_t;
//typedef struct sbuf lomac_log_t;

extern void init_subject_lattr(lomac_subject_t *, lattr_t *);
void set_subject_lattr(lomac_subject_t *, lattr_t);
void get_subject_lattr(lomac_subject_t *, lattr_t *);
void set_object_lattr(lomac_object_t *, lattr_t);
void get_object_lattr(const lomac_object_t *, lattr_t *);
int subject_do_not_demote(lomac_subject_t *);

#endif /* KERNEL_INTERFACE_H */
